import React, { useState } from 'react';
import { CommandItem, HelpTopic, FSNode } from '../types';
import { COMMANDS_DATA, HELP_TOPICS } from '../data/commands';
import { 
  Search, Terminal, Copy, ArrowLeftRight, HelpCircle, 
  ChevronDown, ChevronUp, Check, Info, Globe, Folder, 
  FileText, ExternalLink, StopCircle, PlayCircle, ShieldCheck,
  RefreshCw, ArrowLeft, ArrowRight
} from 'lucide-react';
import { resolvePath, findNodeByPath } from '../utils/fsUtils';

interface ManualTabsProps {
  onInjectCommand: (cmd: string, runImmediately: boolean) => void;
  isPythonInstalled?: boolean;
  setIsPythonInstalled?: (v: boolean) => void;
  runningServers?: Array<{ port: number; path: string; host: string }>;
  setRunningServers?: React.Dispatch<React.SetStateAction<Array<{ port: number; path: string; host: string }>>>;
  vfs?: FSNode;
}

export default function ManualTabs({ 
  onInjectCommand, 
  isPythonInstalled = false, 
  setIsPythonInstalled, 
  runningServers = [], 
  setRunningServers, 
  vfs 
}: ManualTabsProps) {
  const [activeTab, setActiveTab] = useState<'commands' | 'tutorials' | 'about' | 'localhost'>('commands');
  const [browserPath, setBrowserPath] = useState<string>(''); // relative to server root
  const [htmlViewMode, setHtmlViewMode] = useState<'preview' | 'code'>('preview');
  const [browserHistory, setBrowserHistory] = useState<string[]>(['']);
  const [browserHistoryIdx, setBrowserHistoryIdx] = useState<number>(0);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedTopic, setExpandedTopic] = useState<string | null>('developerOptions');
  const [expandedCmdId, setExpandedCmdId] = useState<string | null>(null);

  // Categories translation and color mapping
  const categoriesList = [
    { key: 'all', labelAr: 'الكل', labelEn: 'All' },
    { key: 'adb-basic', labelAr: 'ADB الأساسية', labelEn: 'ADB Basics' },
    { key: 'adb-advanced', labelAr: 'ADB المتقدمة', labelEn: 'ADB Advanced' },
    { key: 'package-manager', labelAr: 'إدارة الحزم (pm)', labelEn: 'Package Manager' },
    { key: 'activity-manager', labelAr: 'إدارة المهام (am)', labelEn: 'Activity Manager' },
    { key: 'terminal-basic', labelAr: 'أوامر الطرفية', labelEn: 'Terminal' },
    { key: 'system-info', labelAr: 'معلومات النظام', labelEn: 'System Info' },
    { key: 'termux', labelAr: 'أوامر Termux', labelEn: 'Termux' },
  ];

  // Filtering commands
  const filteredCommands = COMMANDS_DATA.filter((item) => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch = 
      item.command.toLowerCase().includes(query) ||
      item.descriptionAr.toLowerCase().includes(query) ||
      item.descriptionEn.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => {
      setCopiedId(null);
    }, 1500);
  };

  return (
    <div id="manual-tabs-container" className="flex flex-col h-full bg-[#111112] border border-neutral-800 rounded-xl overflow-hidden shadow-xl text-neutral-300">
      
      {/* Category Header switcher */}
      <div className="flex border-b border-neutral-800 bg-neutral-900 select-none">
        <button
          id="btn-tab-commands"
          type="button"
          onClick={() => setActiveTab('commands')}
          className={`flex-1 py-3 text-center text-sm font-semibold transition ${
            activeTab === 'commands'
              ? 'bg-neutral-800 text-white border-b-2 border-neutral-500 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850'
          } cursor-pointer`}
        >
          <div className="flex items-center justify-center gap-2">
            <Terminal size={16} />
            <span>قاموس الأوامر الأندرويد</span>
          </div>
        </button>
        <button
          id="btn-tab-tutorials"
          type="button"
          onClick={() => setActiveTab('tutorials')}
          className={`flex-1 py-3 text-center text-sm font-semibold transition ${
            activeTab === 'tutorials'
              ? 'bg-neutral-800 text-white border-b-2 border-neutral-500 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850'
          } cursor-pointer`}
        >
          <div className="flex items-center justify-center gap-2">
            <HelpCircle size={16} />
            <span>التعليمات</span>
          </div>
        </button>
        <button
          id="btn-tab-about"
          type="button"
          onClick={() => setActiveTab('about')}
          className={`flex-1 py-3 text-center text-sm font-semibold transition ${
            activeTab === 'about'
              ? 'bg-neutral-800 text-white border-b-2 border-neutral-500 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850'
          } cursor-pointer`}
        >
          <div className="flex items-center justify-center gap-2">
            <Info size={16} />
            <span>حول التطبيق / About</span>
          </div>
        </button>
        <button
          id="btn-tab-localhost"
          type="button"
          onClick={() => setActiveTab('localhost')}
          className={`flex-1 py-3 text-center text-sm font-semibold transition ${
            activeTab === 'localhost'
              ? 'bg-neutral-800 text-white border-b-2 border-neutral-500 font-bold'
              : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-850'
          } cursor-pointer`}
        >
          <div className="flex items-center justify-center gap-2">
            <Globe size={16} className={runningServers.length > 0 ? 'text-emerald-400 animate-pulse' : 'text-neutral-400'} />
            <span className="flex items-center gap-1">
              <span>Localhost</span>
              {runningServers.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-ping" />
              )}
            </span>
          </div>
        </button>
      </div>

      {activeTab === 'commands' ? (
        <div className="flex flex-col flex-1 overflow-hidden" id="commands-tab-content">
          {/* Search bar & filter pills */}
          <div className="p-3 bg-neutral-900 border-b border-neutral-800 flex flex-col gap-3">
            <div className="relative">
              <Search className="absolute right-3 top-2.5 text-neutral-500" size={16} />
              <input
                id="cmd-search-input"
                type="text"
                placeholder="ابحث عن أمر أو وظيفة باللغة العربية أو الإنجليزية..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-9 pl-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-lg text-sm text-neutral-200 focus:outline-none focus:border-neutral-600 transition text-right"
                dir="rtl"
              />
            </div>

            {/* Category horizontal scrolling selector */}
            <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-thin scrollbar-thumb-neutral-800">
              {categoriesList.map((cat) => (
                <button
                  id={`cat-pill-${cat.key}`}
                  key={cat.key}
                  type="button"
                  onClick={() => setSelectedCategory(cat.key)}
                  className={`px-3 py-1 rounded-full text-xs whitespace-nowrap transition cursor-pointer shrink-0 ${
                    selectedCategory === cat.key
                      ? 'bg-neutral-200 text-neutral-900 font-bold'
                      : 'bg-neutral-800 text-neutral-400 hover:bg-neutral-750'
                  }`}
                >
                  {cat.labelAr}
                </button>
              ))}
            </div>
          </div>

          {/* Commands listings */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-neutral-800" id="commands-list-scroll">
            {filteredCommands.length > 0 ? (
              filteredCommands.map((item) => {
                const isExpanded = expandedCmdId === item.id;
                return (
                  <div
                    id={`cmd-card-${item.id}`}
                    key={item.id}
                    className={`bg-[#161618] border border-neutral-800/80 rounded-lg overflow-hidden transition-all duration-150 p-3 hover:border-neutral-700`}
                  >
                    {/* Command header Row */}
                    <div 
                      className="flex items-center justify-between cursor-pointer"
                      onClick={() => setExpandedCmdId(isExpanded ? null : item.id)}
                    >
                      <div className="flex flex-col gap-1 text-left">
                        <code className="text-[13px] font-bold font-mono text-zinc-100 bg-neutral-950 px-2 py-0.5 rounded border border-neutral-800 mr-2 inline-block">
                          {item.command}
                        </code>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] bg-neutral-850 px-2 py-0.5 rounded text-neutral-500 font-mono hidden sm:inline">
                          {categoriesList.find(c => c.key === item.category)?.labelAr || item.category}
                        </span>
                        {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                      </div>
                    </div>

                    {/* Brief description in Arabic */}
                    <p className="mt-2 text-xs text-neutral-400 font-normal leading-relaxed text-right" dir="rtl">
                      {item.descriptionAr}
                    </p>

                    {/* Expanded details */}
                    {isExpanded && (
                      <div className="mt-3.5 pt-3.5 border-t border-neutral-850 space-y-3 text-xs bg-neutral-900/50 p-2.5 rounded-md">
                        <div className="flex justify-between items-center border-b border-neutral-800 pb-2">
                          <span className="text-neutral-500 font-mono">English desc:</span>
                          <span className="text-neutral-300 text-left font-sans">{item.descriptionEn}</span>
                        </div>
                        
                        <div className="space-y-1 text-right">
                          <span className="text-neutral-500 block">مثال للاستخدام:</span>
                          <code className="block bg-black p-2 rounded text-zinc-300 font-mono text-left block border border-neutral-800 whitespace-pre-wrap overflow-x-auto">
                            {item.example}
                          </code>
                        </div>

                        {/* Interactive Buttons */}
                        <div className="flex items-center justify-end gap-2.5 pt-2">
                          <button
                            id={`btn-copy-${item.id}`}
                            type="button"
                            onClick={() => handleCopy(item.example, item.id)}
                            className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 px-3 py-1.5 rounded flex items-center gap-1 transition cursor-pointer text-[11px]"
                            title="نسخ الأمر للحافظة"
                          >
                            {copiedId === item.id ? (
                              <>
                                <Check size={13} className="text-green-400" />
                                <span className="text-green-400">تم النسخ</span>
                              </>
                            ) : (
                              <>
                                <Copy size={13} />
                                <span>نسخ</span>
                              </>
                            )}
                          </button>

                          <button
                            id={`btn-inject-${item.id}`}
                            type="button"
                            onClick={() => onInjectCommand(item.example.split(' ')[0] === 'adb' || item.example.split(' ')[0] === 'pkg' || item.example.split(' ')[0] === 'pm' || item.example.split(' ')[0] === 'am' || item.example.split(' ')[0] === 'getprop' || item.example.split(' ')[0] === 'dumpsys' || item.example.split(' ')[0] === 'wm' || item.example.split(' ')[0] === 'logcat' || item.example.split(' ')[0] === 'su' ? item.example : item.example, false)}
                            className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 px-3 py-1.5 rounded flex items-center gap-1 transition cursor-pointer text-[11px]"
                            title="حقن الأمر داخل محاكي Terminal"
                          >
                            <ArrowLeftRight size={13} />
                            <span>تعديل وحقن</span>
                          </button>

                          <button
                            id={`btn-run-${item.id}`}
                            type="button"
                            onClick={() => onInjectCommand(item.example, true)}
                            className="bg-white hover:bg-neutral-200 text-neutral-900 font-bold px-3 py-1.5 rounded flex items-center gap-1 transition cursor-pointer text-[11px]"
                            title="تشغيل الأمر مباشرة في المحاكي"
                          >
                            <Terminal size={13} />
                            <span>تشغيل مباشر</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center text-neutral-500 text-sm">
                لا توجد أوامر مطابقة لبحثك في الأندرويد أو ADB.
              </div>
            )}
          </div>
        </div>
      ) : activeTab === 'tutorials' ? (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-thin scrollbar-thumb-neutral-800" id="tutorials-tab-content">
          <div className="text-right mb-2" dir="rtl">
            <h3 className="text-sm font-bold text-neutral-200">الأدلة والتعليمات السريعة</h3>
            <p className="text-xs text-neutral-500 mt-1">
              مجموعات تعليمية مبسطة لمساعدتك في تهيئة بيئة التطوير للأندرويد:
            </p>
          </div>

          {Object.entries(HELP_TOPICS).map(([key, topic]) => {
            const isExpanded = expandedTopic === key;
            return (
              <div
                id={`tutorial-${key}`}
                key={key}
                className="bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden transition hover:border-neutral-750"
              >
                <button
                  type="button"
                  onClick={() => setExpandedTopic(isExpanded ? null : key)}
                  className="w-full p-4 flex items-center justify-between text-right font-medium text-sm transition text-neutral-200 hover:bg-neutral-850 cursor-pointer"
                  dir="rtl"
                >
                  <div className="flex items-center gap-2">
                    <span className="p-1 rounded-md bg-neutral-800">
                      <HelpCircle size={16} className="text-neutral-400" />
                    </span>
                    <span className="font-bold text-neutral-200">{topic.titleAr}</span>
                  </div>
                  {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>

                {isExpanded && (
                  <div className="p-4 bg-neutral-950/60 border-t border-neutral-850 text-xs text-neutral-400 space-y-3 leading-relaxed text-right" dir="rtl">
                    <p className="text-[11px] text-neutral-500 font-mono text-left mb-2" dir="ltr">
                      {topic.titleEn}
                    </p>
                    <ol className="list-decimal list-inside space-y-2 pr-2">
                      {topic.steps.map((step, idx) => (
                        <li key={idx} className="text-neutral-300">
                          <span className="font-sans">{step}</span>
                        </li>
                      ))}
                    </ol>

                    {/* Helper action for tutorials */}
                    {key === 'termuxSetup' && (
                      <div className="mt-4 pt-3 border-t border-neutral-800 flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => onInjectCommand('pkg update && pkg upgrade', true)}
                          className="px-3 py-1.5 bg-neutral-805 hover:bg-neutral-800 text-white rounded text-[11px] transition font-bold"
                        >
                          محاكاة تحديث حزم ترمكس
                        </button>
                      </div>
                    )}
                    {key === 'wirelessAdb' && (
                      <div className="mt-4 pt-3 border-t border-neutral-800 flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => onInjectCommand('adb connect 192.168.1.100:5555', true)}
                          className="px-3 py-1.5 bg-neutral-805 hover:bg-neutral-800 text-white rounded text-[11px] transition font-bold"
                        >
                          محاكاة اتصال ADB لاسلكي
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : activeTab === 'about' ? (
        <div className="flex-1 overflow-y-auto p-6 flex flex-col items-center justify-center text-center scrollbar-thin scrollbar-thumb-neutral-800" id="about-tab-content">
          <div className="max-w-md w-full bg-neutral-950 border border-neutral-850 rounded-2xl p-6 shadow-2xl relative overflow-hidden space-y-6">
            
            {/* Minimalist Design Decorative top bar */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-neutral-800 via-neutral-600 to-neutral-800 opacity-80" />
            
            <div className="flex justify-center mb-2">
              <div className="p-4 bg-neutral-900 border border-neutral-800 rounded-full text-neutral-300 shadow-md">
                <Terminal size={32} />
              </div>
            </div>

            <div className="space-y-4">
              <div className="space-y-2">
                <h3 className="text-xl font-black text-white tracking-tight leading-none">
                  حول التطبيق والمهندس المطور
                </h3>
                <p className="text-xs text-neutral-500 font-mono">
                  Android Terminal Shell & ADB Guide v2.0
                </p>
              </div>

              <div className="py-4 border-y border-neutral-900 space-y-1 bg-neutral-900/20 rounded-xl px-4">
                <p className="text-[17px] font-bold text-neutral-200 tracking-wide text-center">
                  تمت البرمجة بواسطة مستور الحربي
                </p>
                <p className="text-sm font-semibold text-neutral-400 font-sans tracking-wide">
                  by mastoor alharbi
                </p>
              </div>

              <p className="text-[11.5px] text-neutral-400 leading-relaxed text-right rtl" dir="rtl">
                تم تصميم نظام محاكي الطرفية ودليل الأوامر هذا بدقة عالية وعناية فائقة لتوفير بيئة تفاعلية ممتازة، تعتمد أسلوب التصميم الرزين الداكن بنسق رمادي فاخر ومريح للعين لتسهيل تجربة التعلم لمهندسي البرمجيات ومطوري الأندرويد.
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-2.5">
              <button
                type="button"
                onClick={() => onInjectCommand('about', true)}
                className="w-full bg-white hover:bg-neutral-200 text-neutral-900 font-black py-2.5 px-4 rounded-xl text-xs transition duration-150 cursor-pointer flex items-center justify-center gap-2"
              >
                <Terminal size={14} />
                <span>تشغيل أمر المبرمج about في الطرفية</span>
              </button>
              
              <p className="text-[10px] text-neutral-600 font-mono">
                Designed & Developed under Grey Concept layout
              </p>
            </div>

          </div>
        </div>
      ) : (
        /* LOCAL WEB SERVER & PYTHON TERMINAL SIMULATOR VIEW (THE "LOCALHOST" TAB) */
        <div className="flex-1 flex flex-col overflow-hidden bg-[#0c0c0e]" id="localhost-tab-content" dir="rtl">
          {!isPythonInstalled ? (
            /* PYTHON NOT INSTALLED UI */
            <div className="flex-1 overflow-y-auto p-5 flex flex-col items-center justify-center text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center text-yellow-500 animate-pulse">
                <Terminal size={28} />
              </div>
              <div className="space-y-2">
                <h3 className="text-base font-black text-neutral-100">مفسّر لغة Python غير مثبت بعد</h3>
                <p className="text-xs text-neutral-400 max-w-sm leading-relaxed">
                  يتطلب تشغيل الخوادم المحلية (.localhost) ترجمة بلغة البايثون. يرجى تفعيل لغة البايثون في بيئة Termux الافتراضية للبدء.
                </p>
              </div>
              <div className="w-full max-w-xs bg-neutral-900/40 p-3.5 border border-neutral-850 rounded-xl space-y-2 text-right text-[11px] font-mono text-neutral-400">
                <div className="flex items-center gap-1.5 text-neutral-300 font-medium mb-1">
                  <div className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
                  <span>خطوات التثبيت المقترحة:</span>
                </div>
                <p>1. اكتب <span className="text-yellow-400">pkg install python</span> بالطرفية.</p>
                <p>2. أو انقر على الزر السريع بالأسفل لحقن وتثبيت الحزمة تلقائياً.</p>
              </div>
              <button
                type="button"
                onClick={() => {
                  onInjectCommand('pkg install python', true);
                }}
                className="bg-yellow-500 hover:bg-yellow-600 text-neutral-950 font-black py-2.5 px-6 rounded-xl text-xs transition active:scale-95 shadow-lg shadow-yellow-500/10 flex items-center gap-2"
              >
                <PlayCircle size={14} />
                <span>تثبيت لغة Python تلقائياً 🚀</span>
              </button>
            </div>
          ) : runningServers.length === 0 ? (
            /* PYTHON INSTALLED BUT NO RUNNING SERVER */
            <div className="flex-1 overflow-y-auto p-5 flex flex-col justify-center items-center text-center space-y-6">
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <ShieldCheck size={28} />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-center gap-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <h3 className="text-base font-black text-neutral-100">بايثون جاهز ونشط (v3.10.6)</h3>
                </div>
                <p className="text-xs text-neutral-400 max-w-sm leading-relaxed">
                  بيئة البايثون نشطة ومثبتة بنجاح! يمكنك الآن تشغيل السيرفر المحلي لمشروعك البرمجي، أو بدء مفسّر الأوامر لكتابة كود البايثون مباشرة.
                </p>
              </div>

              {/* Server Starter Panel */}
              <div className="w-full max-w-sm bg-neutral-900/60 border border-neutral-850 p-4 rounded-2xl text-right space-y-4">
                <div className="space-y-1">
                  <h4 className="text-xs font-black text-neutral-200">خادم ويب محلي (Local HTTP Server)</h4>
                  <p className="text-[10px] text-neutral-500">
                    جاري توجيه الخادم لعرض وإدارة مجلد الملفات الحالي. يمكنك اختبار ملفات HTML مباشرة.
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onInjectCommand('python -m http.server 8000', true)}
                    className="bg-white hover:bg-neutral-200 text-neutral-900 font-bold py-2 rounded-xl text-[11px] transition text-center"
                  >
                    تشغيل سيرفر على 8000
                  </button>
                  <button
                    type="button"
                    onClick={() => onInjectCommand('python -m http.server 8080', true)}
                    className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium py-2 rounded-xl text-[11px] transition text-center"
                  >
                    تشغيل سيرفر على 8080
                  </button>
                </div>

                <div className="pt-2 border-t border-neutral-850/60 flex items-center justify-between">
                  <span className="text-[10px] text-neutral-500 font-mono">Terminal REPL Launcher:</span>
                  <button
                    type="button"
                    onClick={() => onInjectCommand('python', true)}
                    className="text-emerald-400 hover:underline text-[11px] font-black"
                  >
                    بدء محاكي Python Interactive Shell
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* VIRTUAL LOCALHOST BROWSER MODULE */
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Virtual Browser Top Header (Address Bar) */}
              <div className="p-2.5 bg-neutral-900 border-b border-neutral-800 flex items-center gap-2 select-none" dir="ltr">
                {/* Visual back/forward navigation keys */}
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    disabled={browserHistoryIdx === 0}
                    onClick={() => {
                      if (browserHistoryIdx > 0) {
                        const newIdx = browserHistoryIdx - 1;
                        setBrowserHistoryIdx(newIdx);
                        setBrowserPath(browserHistory[newIdx]);
                      }
                    }}
                    className={`p-1.5 rounded-lg transition ${
                      browserHistoryIdx === 0
                        ? 'text-neutral-600 cursor-not-allowed'
                        : 'text-neutral-300 hover:bg-neutral-800 active:scale-90'
                    }`}
                    title="Back"
                  >
                    <ArrowLeft size={14} />
                  </button>
                  <button
                    type="button"
                    disabled={browserHistoryIdx >= browserHistory.length - 1}
                    onClick={() => {
                      if (browserHistoryIdx < browserHistory.length - 1) {
                        const newIdx = browserHistoryIdx + 1;
                        setBrowserHistoryIdx(newIdx);
                        setBrowserPath(browserHistory[newIdx]);
                      }
                    }}
                    className={`p-1.5 rounded-lg transition ${
                      browserHistoryIdx >= browserHistory.length - 1
                        ? 'text-neutral-600 cursor-not-allowed'
                        : 'text-neutral-300 hover:bg-neutral-800 active:scale-90'
                    }`}
                    title="Forward"
                  >
                    <ArrowRight size={14} />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      // refresh loading simulator
                      const originalPath = browserPath;
                      setBrowserPath('__LOADING__');
                      setTimeout(() => setBrowserPath(originalPath), 250);
                    }}
                    className="p-1.5 rounded-lg text-neutral-300 hover:bg-neutral-800 active:scale-90 transition"
                    title="Reload"
                  >
                    <RefreshCw size={12} />
                  </button>
                </div>

                {/* Address Bar Input Form */}
                <div className="flex-1 bg-neutral-950 border border-neutral-800 rounded-lg px-2.5 py-1 flex items-center gap-1.5">
                  <Globe size={11} className="text-emerald-500 shrink-0" />
                  <span className="text-neutral-500 font-mono text-[9.5px]">http://</span>
                  <span className="text-neutral-200 font-mono text-[10.5px]">localhost:{runningServers[0].port}</span>
                  <span className="text-neutral-400 font-mono text-[10.5px] truncate">{browserPath || '/'}</span>
                </div>

                {/* Red Kill Switch to stop server */}
                <button
                  type="button"
                  onClick={() => onInjectCommand(`stop-server ${runningServers[0].port}`, true)}
                  className="bg-red-500/10 hover:bg-red-500 text-red-400 hover:text-white border border-red-500/15 p-1.5 rounded-lg transition shrink-0"
                  title="Stop server"
                >
                  <StopCircle size={14} />
                </button>
              </div>

              {/* Virtual Browser Screen Body */}
              <div className="flex-1 overflow-y-auto bg-neutral-950 text-neutral-300">
                {browserPath === '__LOADING__' ? (
                  <div className="p-8 text-center flex flex-col justify-center items-center h-full space-y-2">
                    <RefreshCw size={20} className="text-neutral-500 animate-spin" />
                    <span className="text-xs font-mono text-neutral-500">Connecting to simulated localhost...</span>
                  </div>
                ) : (() => {
                  const srv = runningServers[0];
                  const rootPath = srv.path;
                  const finalLookupPath = resolvePath(rootPath, browserPath);
                  const node = vfs ? findNodeByPath(vfs, finalLookupPath) : null;

                  const pushNavigation = (nextPath: string) => {
                    const sliced = browserHistory.slice(0, browserHistoryIdx + 1);
                    sliced.push(nextPath);
                    setBrowserHistory(sliced);
                    setBrowserHistoryIdx(sliced.length - 1);
                    setBrowserPath(nextPath);
                  };

                  if (!node) {
                    /* Not Found (404) */
                    return (
                      <div className="p-6 space-y-4" dir="rtl">
                        <div className="space-y-1">
                          <h3 className="text-lg font-bold text-red-400">404 Not Found</h3>
                          <p className="text-xs text-neutral-400">العنصر المطلوب "{browserPath}" غير متوفر على السيرفر المحلي.</p>
                        </div>
                        <div className="bg-neutral-900 p-4 border border-neutral-850 rounded-xl space-y-3">
                          <p className="text-[11px] text-neutral-400">يمكنك إنشاء صفحة بديلة باسم index.html تجريبية فورياً لحل المشكلة واستعراض الويب:</p>
                          <button
                            type="button"
                            onClick={() => {
                              onInjectCommand(`echo '<h1 style="color:#0EA5E9;font-family:sans-serif;text-align:center;margin-top:50px;">أهلاً بك في خادم بايثون! 👋</h1><p style="text-align:center;color:#71717A;">صفحة مخصصة في المجلد الحالي.</p>' > "${finalLookupPath}/index.html"`, true);
                            }}
                            className="bg-sky-500 hover:bg-sky-600 text-neutral-950 font-black px-4 py-2 rounded-lg text-[11px] transition"
                          >
                            إنشاء ملف index.html تجريبي تلقائياً 🛠️
                          </button>
                        </div>
                      </div>
                    );
                  }

                  if (node.type === 'file') {
                    /* File view mode */
                    const isPy = node.name.endsWith('.py');
                    return (
                      <div className="p-4 space-y-4" dir="rtl">
                        <div className="flex items-center justify-between border-b border-neutral-850 pb-2">
                          <div className="flex items-center gap-1.5 shrink-0">
                            <FileText size={14} className="text-gray-400" />
                            <span className="text-xs font-mono font-bold text-white tracking-wide">{node.name}</span>
                          </div>
                          
                          <div className="flex items-center gap-1.5">
                            {isPy && (
                              <button
                                type="button"
                                onClick={() => onInjectCommand(`python "${node.name}"`, true)}
                                className="bg-emerald-500/15 hover:bg-emerald-500 text-emerald-400 hover:text-white px-2.5 py-1 border border-emerald-500/20 rounded-md text-[10.5px] font-black transition"
                              >
                                تشغيل سكربت بايثون ⚙️
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => {
                                // Go up to directory
                                const lastSlash = browserPath.lastIndexOf('/');
                                const parentPath = lastSlash <= 0 ? '' : browserPath.substring(0, lastSlash);
                                pushNavigation(parentPath);
                              }}
                              className="text-xs text-neutral-400 hover:text-white bg-neutral-900 border border-neutral-850 px-2.5 py-1 rounded-md"
                            >
                              العودة للمجلد السابق
                            </button>
                          </div>
                        </div>

                        {/* File details */}
                        <div className="bg-[#0b0b0d] border border-neutral-900 p-3.5 rounded-xl font-mono text-xs overflow-x-auto text-left leading-relaxed text-neutral-300 max-h-[300px] whitespace-pre" dir="ltr">
                          {node.content || '(ملف فارغ)'}
                        </div>
                      </div>
                    );
                  }

                  /* Directory View Mode */
                  const indexNode = node.children ? node.children['index.html'] : undefined;
                  const isWebPage = indexNode && indexNode.type === 'file';

                  if (isWebPage) {
                    /* RENDER INDEX.HTML PREVIEW / CODE SWITCH */
                    const htmlCode = indexNode.content || '';
                    return (
                      <div className="flex flex-col h-full min-h-[350px]">
                        {/* Tab mode toggler */}
                        <div className="flex border-b border-neutral-900 bg-neutral-950 px-3 py-1.5 select-none gap-2" dir="rtl">
                          <button
                            type="button"
                            onClick={() => setHtmlViewMode('preview')}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition ${
                              htmlViewMode === 'preview'
                                ? 'bg-neutral-800 text-white'
                                : 'text-neutral-500 hover:text-neutral-300'
                            }`}
                          >
                            صفحة الويب المخصصة
                          </button>
                          <button
                            type="button"
                            onClick={() => setHtmlViewMode('code')}
                            className={`px-3 py-1 rounded-md text-[11px] font-bold transition ${
                              htmlViewMode === 'code'
                                ? 'bg-neutral-800 text-white'
                                : 'text-neutral-500 hover:text-neutral-300'
                            }`}
                          >
                            عرض السورس كود
                          </button>
                        </div>

                        {htmlViewMode === 'preview' ? (
                          /* Visual preview card rendering */
                          <div className="p-6 flex flex-col items-center justify-center text-center space-y-4 bg-white/5 border border-white/5 m-4 rounded-2xl" dir="rtl">
                            <div className="w-12 h-12 bg-sky-500/10 text-sky-400 border border-sky-500/20 rounded-full flex items-center justify-center">
                              <Globe size={24} />
                            </div>
                            <div className="space-y-1">
                              <h4 className="text-base font-black text-white">معاينة: index.html</h4>
                              <p className="text-xs text-neutral-400 font-sans max-w-sm">
                                تم محاكاة تصفح صفحة الخادم بنجاح. النص الأساسي في الصفحة:
                              </p>
                            </div>
                            
                            {/* Visual rendering box */}
                            <div className="w-full max-w-sm bg-neutral-950/70 border border-neutral-900 rounded-xl p-4 text-center text-sm font-sans space-y-2">
                              {/* Simple html parser fallback */}
                              <div className="text-neutral-200 font-black">
                                {htmlCode.replace(/<[^>]*>/g, '').trim().substring(0, 150) || 'مرحباً من السيرفر المحلي!'}
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => {
                                // Navigate around directory listing anyway
                                pushNavigation(browserPath + '/__bypass_index__');
                              }}
                              className="text-[10px] text-sky-400 hover:underline font-mono"
                            >
                              تخطي الملف واستعراض الملفات مباشرة
                            </button>
                          </div>
                        ) : (
                          /* Raw Source Code Viewer */
                          <div className="p-4" dir="rtl">
                            <div className="bg-[#0b0b0d] border border-neutral-900 p-3.5 rounded-xl font-mono text-xs overflow-x-auto text-left leading-relaxed text-neutral-300 max-h-[300px] whitespace-pre" dir="ltr">
                              {htmlCode}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  }

                  /* Pure Directory Listing fallback */
                  let contentsList: string[] = [];
                  if (node.children) {
                    contentsList = Object.keys(node.children).sort();
                  }

                  // If bypass was selected above, ignore.
                  const showDirectoryContents = true;

                  return (
                    <div className="p-4" dir="rtl">
                      <div className="flex items-center justify-between border-b border-neutral-850 pb-2.5 mb-2.5">
                        <span className="text-xs font-bold text-neutral-200">فهرس المحتويات: {browserPath || '/'}</span>
                        <div className="flex items-center gap-1">
                          <span className="text-[10.5px] text-emerald-400 font-mono">active: localhost:{srv.port}</span>
                        </div>
                      </div>

                      {/* Directories & Files explorer rows */}
                      <div className="space-y-1.5">
                        {/* Parent Directory handle */}
                        {browserPath && browserPath !== '/' && (
                          <button
                            type="button"
                            onClick={() => {
                              const lastSlash = browserPath.lastIndexOf('/');
                              const parentPath = lastSlash <= 0 ? '' : browserPath.substring(0, lastSlash);
                              pushNavigation(parentPath);
                            }}
                            className="w-full text-right hover:bg-neutral-900/40 p-2 rounded-lg flex items-center justify-start gap-2.5 transition text-xs font-semibold text-neutral-400 hover:text-white"
                          >
                            <Folder size={15} className="text-neutral-500" />
                            <span>.. / (المجلد الأعلى)</span>
                          </button>
                        )}

                        {contentsList.length === 0 ? (
                          <div className="p-6 text-center text-neutral-500 text-xs">
                            لا توجد ملفات أو مجلدات هنا. يمكنك إنشاء ملفات باسم touch index.html لتنشيطها.
                          </div>
                        ) : (
                          contentsList.map((name) => {
                            const isBypassed = name === '__bypass_index__';
                            if (isBypassed) return null;

                            const childNode = node.children ? node.children[name] : undefined;
                            if (!childNode) return null;

                            const isDir = childNode.type === 'dir';
                            const nextFullPath = browserPath === '' ? `/${name}` : `${browserPath}/${name}`;

                            return (
                              <button
                                type="button"
                                key={name}
                                onClick={() => {
                                  pushNavigation(nextFullPath);
                                }}
                                className="w-full text-right hover:bg-neutral-900/40 p-2 rounded-lg flex items-center justify-start gap-2.5 transition text-xs font-mono text-neutral-300"
                              >
                                {isDir ? (
                                  <Folder size={15} className="text-amber-500 shrink-0" />
                                ) : (
                                  <FileText size={15} className="text-slate-400 shrink-0" />
                                )}
                                <span className={isDir ? 'font-bold text-neutral-200' : 'text-neutral-350 hover:underline'}>
                                  {name}
                                </span>
                              </button>
                            );
                          })
                        )}
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
