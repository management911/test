import React, { useState } from 'react';
import { X, Save, FileText } from 'lucide-react';

interface VirtualNanoProps {
  filename: string;
  initialContent: string;
  onSave: (content: string) => void;
  onClose: () => void;
}

export default function VirtualNano({ filename, initialContent, onSave, onClose }: VirtualNanoProps) {
  const [content, setContent] = useState(initialContent);

  const handleSave = () => {
    onSave(content);
  };

  return (
    <div id="virtual-nano-editor" className="border-2 border-neutral-700 rounded-lg bg-neutral-900 text-neutral-300 font-mono flex flex-col h-72 w-full select-none overflow-hidden my-2 shadow-2xl">
      {/* Nano Header */}
      <div className="bg-neutral-800 px-3 py-1.5 flex items-center justify-between border-b border-neutral-700 text-xs text-neutral-400 font-medium">
        <div className="flex items-center gap-1.5">
          <FileText size={14} className="text-neutral-500" />
          <span>GNU nano 7.2 (محرر النصوص الافتراضي)</span>
        </div>
        <div className="bg-neutral-950 px-2.5 py-0.5 rounded text-neutral-300 border border-neutral-700 font-semibold">
          ملف: {filename}
        </div>
        <div className="flex items-center gap-2">
          <button 
            type="button" 
            onClick={handleSave} 
            className="flex items-center gap-1 hover:text-white px-2 py-0.5 bg-neutral-700 rounded text-neutral-300 transition duration-150 cursor-pointer"
            title="حفظ الملف"
          >
            <Save size={12} />
            <span>حفظ</span>
          </button>
          <button 
            type="button" 
            onClick={onClose} 
            className="text-neutral-400 hover:text-neutral-200 transition p-0.5 cursor-pointer"
            title="إغلاق المحرر"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Nano Editor Textarea */}
      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="w-full flex-1 p-3 bg-neutral-950 text-neutral-200 font-mono text-sm leading-relaxed resize-none focus:outline-none border-0"
        placeholder="اكتب شيئاً هنا..."
        dir="ltr"
        id="nano-textarea"
      />

      {/* Nano Shortcut Guide */}
      <div className="bg-neutral-800 text-[10px] text-neutral-400 p-2 grid grid-cols-4 gap-2 border-t border-neutral-700 text-center select-none">
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^G</span> مساعدة</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^O</span> كتابة</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^R</span> قراءة</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^Y</span> الصفحة السابقة</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^K</span> قص نص</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^U</span> لصق نص</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^C</span> الموضع الحالي</div>
        <div><span className="bg-neutral-900 font-bold px-1 rounded inline-block text-white">^X</span> خروج</div>
      </div>
    </div>
  );
}
