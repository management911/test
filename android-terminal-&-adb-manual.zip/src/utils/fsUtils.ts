import { FSNode } from '../types';

export const getInitialVFS = (): FSNode => {
  return {
    name: '/',
    type: 'dir',
    children: {
      'system': {
        name: 'system',
        type: 'dir',
        children: {
          'build.prop': {
            name: 'build.prop',
            type: 'file',
            content: `ro.build.version.release=14\nro.build.version.sdk=34\nro.product.model=Pixel 8 Pro\nro.product.brand=google\nro.product.cpu.abi=arm64-v8a\nro.serialno=ADB83749X91\nro.debuggable=1\nro.secure=0\n`
          },
          'bin': {
            name: 'bin',
            type: 'dir',
            children: {
              'sh': { name: 'sh', type: 'file', content: '# Shell binary' },
              'pm': { name: 'pm', type: 'file', content: '# Package manager script' },
              'am': { name: 'am', type: 'file', content: '# Activity manager script' },
              'su': { name: 'su', type: 'file', content: '# SuperUser Switcher' },
              'getprop': { name: 'getprop', type: 'file', content: '# System properties reader' }
            }
          }
        }
      },
      'etc': {
        name: 'etc',
        type: 'dir',
        children: {
          'hosts': { name: 'hosts', type: 'file', content: '127.0.0.1  localhost\n::1  localhost\n' },
          'resolv.conf': { name: 'resolv.conf', type: 'file', content: 'nameserver 8.8.8.8\nnameserver 8.8.4.4\n' }
        }
      },
      'data': {
        name: 'data',
        type: 'dir',
        children: {
          'user': {
            name: 'user',
            type: 'dir',
            children: {
              '0': {
                name: '0',
                type: 'dir',
                children: {
                  'com.termux': {
                    name: 'com.termux',
                    type: 'dir',
                    children: {
                      'files': {
                        name: 'files',
                        type: 'dir',
                        children: {
                          'home': {
                            name: 'home',
                            type: 'dir',
                            children: {
                              '.bashrc': {
                                name: '.bashrc',
                                type: 'file',
                                content: 'alias ll="ls -la"\nalias update="pkg update && pkg upgrade"\necho "مرحباً بك في ترمكس أندرويد!"\n'
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      },
      'sdcard': {
        name: 'sdcard',
        type: 'dir',
        children: {
          'Download': {
            name: 'Download',
            type: 'dir',
            children: {
              'welcome_note.txt': {
                name: 'welcome_note.txt',
                type: 'file',
                content: `أهلاً بك في محاكي أسطر أوامر الأندرويد المصمم بالكامل باللونين الأسود والرمادي.\n\nيمكنك تجربة جميع الأوامر مثل:\n- ls\n- cd /sdcard/Download\n- mkdir test_folder\n- edit note.txt (لفتح محرر النصوص nano)\n- logcat (لعرض سجلات تشخيص الأخطاء المباشرة)\n- neofetch (لعرض شعار الأندرويد والخصائص)\n- getprop (لقراءة معلومات الهاتف)\n- su (للتحول إلى مستخدم الروت الخارق!)\n`
              },
              'termux_tutorial.sh': {
                name: 'termux_tutorial.sh',
                type: 'file',
                content: `#!/bin/sh\necho "تجهيز تطبيق Termux الجديد:"\necho "1. pkg update"\necho "2. termux-setup-storage"\n`
              }
            }
          },
          'DCIM': {
            name: 'DCIM',
            type: 'dir',
            children: {
              'Camera': {
                name: 'Camera',
                type: 'dir',
                children: {}
              }
            }
          },
          'Documents': {
            name: 'Documents',
            type: 'dir',
            children: {
              'secret_database.db': {
                name: 'secret_database.db',
                type: 'file',
                content: 'SQLITE FILE - ENCRYPTED ROOT'
              }
            }
          }
        }
      }
    }
  };
};

export const resolvePath = (currentPath: string, targetPath: string): string => {
  if (targetPath.startsWith('/')) {
    currentPath = '/';
  }
  
  const parts = targetPath.split('/').filter(Boolean);
  const currentParts = currentPath.split('/').filter(Boolean);
  
  for (const part of parts) {
    if (part === '.') {
      continue;
    } else if (part === '..') {
      currentParts.pop();
    } else {
      currentParts.push(part);
    }
  }
  
  return '/' + currentParts.join('/');
};

export const findNodeByPath = (root: FSNode, path: string): FSNode | null => {
  if (path === '/' || path === '') return root;
  
  const parts = path.split('/').filter(Boolean);
  let current: FSNode = root;
  
  for (const part of parts) {
    if (current.type !== 'dir' || !current.children) {
      return null;
    }
    const next = current.children[part];
    if (!next) {
      return null;
    }
    current = next;
  }
  
  return current;
};

export const createNodeInPath = (
  root: FSNode,
  parentPath: string,
  name: string,
  type: 'file' | 'dir',
  content: string = ''
): { success: boolean; root: FSNode; error?: string } => {
  // Clone root VFS deep enough
  const rootClone = JSON.parse(JSON.stringify(root)) as FSNode;
  
  const parentNode = findNodeByPath(rootClone, parentPath);
  if (!parentNode) {
    return { success: false, root, error: 'المسار المحدد غير موجود.' };
  }
  
  if (parentNode.type !== 'dir') {
    return { success: false, root, error: 'المسار الأب ليس مجلداً.' };
  }
  
  if (!parentNode.children) {
    parentNode.children = {};
  }
  
  if (parentNode.children[name]) {
    return { success: false, root, error: `الملف أو المجلد "${name}" موجود بالفعل.` };
  }
  
  parentNode.children[name] = {
    name,
    type,
    content: type === 'file' ? content : undefined,
    children: type === 'dir' ? {} : undefined,
  };
  
  return { success: true, root: rootClone };
};

export const updateFileContent = (
  root: FSNode,
  filePath: string,
  content: string
): { success: boolean; root: FSNode; error?: string } => {
  const rootClone = JSON.parse(JSON.stringify(root)) as FSNode;
  const node = findNodeByPath(rootClone, filePath);
  
  if (!node) {
    // If doesn't exist, we must create it.
    const parts = filePath.split('/');
    const name = parts.pop() || '';
    const parentPath = parts.join('/') || '/';
    return createNodeInPath(root, parentPath, name, 'file', content);
  }
  
  if (node.type !== 'file') {
    return { success: false, root, error: 'الهدف مجلد وليس ملفاً.' };
  }
  
  node.content = content;
  return { success: true, root: rootClone };
};

export const removeNodeFromPath = (
  root: FSNode,
  parentPath: string,
  name: string
): { success: boolean; root: FSNode; error?: string } => {
  const rootClone = JSON.parse(JSON.stringify(root)) as FSNode;
  const parentNode = findNodeByPath(rootClone, parentPath);
  
  if (!parentNode || parentNode.type !== 'dir' || !parentNode.children || !parentNode.children[name]) {
    return { success: false, root, error: 'الملف أو المجلد غير موجود للحذف.' };
  }
  
  delete parentNode.children[name];
  return { success: true, root: rootClone };
};
