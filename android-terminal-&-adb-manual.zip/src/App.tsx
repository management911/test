import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal as TerminalIcon, 
  Cpu, 
  Battery, 
  Wifi, 
  Shield, 
  RefreshCw, 
  Play, 
  Keyboard, 
  Delete, 
  CornerDownLeft, 
  StopCircle, 
  Smartphone, 
  FileText, 
  Check, 
  Copy,
  FolderOpen,
  Info,
  Upload
} from 'lucide-react';
import { FSNode, TerminalHistoryItem } from './types';
import { getInitialVFS, resolvePath, findNodeByPath, createNodeInPath, updateFileContent, removeNodeFromPath } from './utils/fsUtils';
import ManualTabs from './components/ManualTabs';
import VirtualNano from './components/VirtualNano';

function splitChainedCommands(commandLine: string) {
  const result: { command: string; operator: '&&' | '||' | 'START' }[] = [];
  let currentCmd = '';
  let i = 0;
  let inDoubleQuote = false;
  let inSingleQuote = false;
  let currentOperator: '&&' | '||' | 'START' = 'START';

  while (i < commandLine.length) {
    const char = commandLine[i];
    const nextChar = commandLine[i + 1];

    if (char === '"' && commandLine[i - 1] !== '\\') {
      inDoubleQuote = !inDoubleQuote;
      currentCmd += char;
      i++;
    } else if (char === "'" && commandLine[i - 1] !== '\\') {
      inSingleQuote = !inSingleQuote;
      currentCmd += char;
      i++;
    } else if (!inDoubleQuote && !inSingleQuote && char === '&' && nextChar === '&') {
      result.push({ command: currentCmd.trim(), operator: currentOperator });
      currentCmd = '';
      currentOperator = '&&';
      i += 2;
    } else if (!inDoubleQuote && !inSingleQuote && char === '|' && nextChar === '|') {
      result.push({ command: currentCmd.trim(), operator: currentOperator });
      currentCmd = '';
      currentOperator = '||';
      i += 2;
    } else {
      currentCmd += char;
      i++;
    }
  }
  
  if (currentCmd.trim()) {
    result.push({ command: currentCmd.trim(), operator: currentOperator });
  }
  
  return result;
}

// Helper to get precise local timestamp YYYY-MM-DD HH:MM:SS
const getPreciseTimestamp = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
};

const commandHints: Record<string, string> = {
  help: ' [command] (مساعدة الأوامر)',
  man: ' [command] (عرض دليل واستخدام الأوامر المتاحة)',
  clear: ' (تنظيف شاشة الطرفية)',
  history: ' [limit] (عرض سجل الأوامر)',
  about: ' (عن المحاكي ومطور التطبيق)',
  neofetch: ' (معلومات الأندرويد والنظام والمواصفات)',
  ls: ' [path] [-la] (عرض قائمة الملفات والمجلدات)',
  dir: ' [path] (عرض المجلدات الفرعية فقط)',
  cd: ' [path] (تغيير مسار العمل الحالي cd)',
  pwd: ' (طباعة وعرض مسار المجلد الحالي)',
  mv: ' [source] [destination] (نقل مستند أو تغيير مسمى)',
  cp: ' [source] [destination] (نسخ ملف أو مجلد بالكامل)',
  curl: ' [url] (طلب ويب أو جلب بيانات HTTP API)',
  wget: ' [url] (تنزيل ملف خارجي من الويب)',
  get: ' [url] (تنزيل وقراءة محتوى من الويب)',
  apt: ' install | update | remove [package] (مدير الحزم)',
  'apt-get': ' install | update | remove [package]',
  'apt-install': ' [package] (تثبيت حزمة نظام جديدة)',
  ping: ' [host] (فحص سرعة استجابة السلك والشبكة)',
  mkdir: ' [directory_name] (إنشاء مجلد فرعي جديد)',
  touch: ' [file_name] (إنشاء وتوليد ملف فارغ)',
  rm: ' [-rf] [file_or_directory] (أمر الحذف النهائي)',
  cat: ' [file_path] (طباعة وقراءة ملف نصوص)',
  tail: ' [-n lines] [file_path] (عرض نهاية الملف النصي)',
  find: ' [path] [-name pattern] (البحث عن الملفات والمجلدات تكرارياً)',
  echo: ' [text] [> file] (كتابة نص أو تغذية ملف بالإدخال)',
  grep: ' [pattern] [file_path] (البحث وتصفية النصوص الذكي)',
  nano: ' [file_path] (تشغيل محرر النصوص المتقدم Nano)',
  edit: ' [file_path] (بدء تعديل ملف نصي سريع)',
  getprop: ' [property_name] (قراءة خصائص مصفوفة بيئة النواة)',
  dumpsys: ' battery (فرز خدمات وجداول طاقة البطارية)',
  wm: ' size | density [value] (تعديل دقة الشاشة)',
  pm: ' list packages [-3|-s] | install [apk] | clear [package] (مدير الحزم)',
  sh: ' (فتح شيل أوامر فرعي bash)',
  shell: ' (بيئة الباش الحالية)',
  'install-apk': ' [apk_file] (تثبيت تطبيق أندرويد يدوي)',
  gradlew: ' assembleDebug (بناء حزمة أندرويد عبر Gradle)',
  apktool: ' d [app.apk] | b [folder] (تفكيك وإعادة تجميع التطبيقات)',
  'build-apk': ' [folder] (توليد وبناء ملف APK)',
  apkbuild: ' [folder] (بناء ملف APK)',
  logcat: ' (مراقبة سجل عمليات الأندرويد الحية)',
  ps: ' (عرض العمليات والوظائف الفعالة بنظام لينكس)',
  top: ' (مراقبة استهلاك النواة وموارد المعالج والذاكرة)',
  uptime: ' (توقيت تشغيل خادم الجهاز دون إطفاء)',
  df: ' (المساحة المستغلة بالتخزين الفيزيائي)',
  free: ' (فحص الذاكرة العشوائية RAM ومساحة التخزين المؤقت)',
  reboot: ' (إعادة تشغيل المحاكي لنهجه الافتراضي)',
  adb: ' install [apk] | connect [ip_address] (أمر تحكم الجسر اللاسلكي)',
  pkg: ' install | update [package] (تثبيت حزم ترمكس)',
  'termux-battery-status': ' (تفاصيل دقيقة لبطارية الجهاز الافتراضية)',
  'termux-vibrate': ' [-d duration_ms] (إصدار نبضات اهتزازية)',
  alias: ' [name]="[command]" (تسمية اسم مستعار)',
  unalias: ' [name] (إلغاء الاسم المستعار المحدد)',
  id: ' (عرض معرف الهوية والمجموعات الحالية uid/gid)',
  'login:root': ' (تسجيل الدخول المباشر كمسؤول خارق root)',
  python: ' [file.py] (تشغيل ملف بايثون أو بدء مفسر الأوامر التفاعلي)',
  'stop-server': ' [port] (إيقاف خادم localhost محلي يعمل على منفذ محدد)'
};

export default function App() {
  // Virtual System State
  const [vfs, setVfs] = useState<FSNode>(getInitialVFS());
  const [currentPath, setCurrentPath] = useState<string>('/sdcard/Download');
  const [isRoot, setIsRoot] = useState<boolean>(false);
  const [batteryLevel, setBatteryLevel] = useState<number>(84);
  const [batteryCharging, setBatteryCharging] = useState<boolean>(false);
  const [isConnected, setIsConnected] = useState<boolean>(true);

  // Python & Localhost Server State
  const [isPythonInstalled, setIsPythonInstalled] = useState<boolean>(false);
  const [runningServers, setRunningServers] = useState<Array<{ port: number; path: string; host: string }>>([]);
  const [pythonReplActive, setPythonReplActive] = useState<boolean>(false);
  const [pythonEnv, setPythonEnv] = useState<Record<string, any>>({});
  
  // Terminal I/O State
  const [inputVal, setInputVal] = useState<string>('');

  // Subtle tooltip / auto-complete hint calculation
  const getCmdSuggestion = () => {
    const trimmed = inputVal.trimStart();
    if (!trimmed) return null;
    const parts = trimmed.split(/\s+/);
    if (!parts.length || !parts[0]) return null;
    const typedCmd = parts[0].toLowerCase();
    
    // Check if we have exact match
    if (commandHints[typedCmd] !== undefined) {
      return {
        command: typedCmd,
        hint: commandHints[typedCmd],
        isPartial: false
      };
    }
    
    // Check if we have partial match - only if user typed 1 word without any spaces
    if (parts.length === 1) {
      const candidates = Object.keys(commandHints).filter(cmd => cmd.startsWith(typedCmd));
      if (candidates.length > 0) {
        // Find best alphabetical match
        const matched = candidates.sort((a, b) => a.localeCompare(b))[0];
        return {
          command: matched,
          hint: commandHints[matched],
          isPartial: true
        };
      }
    }
    
    return null;
  };

  const currentSuggestion = getCmdSuggestion();
  const [history, setHistory] = useState<TerminalHistoryItem[]>([
    {
      id: 'init-1',
      text: 'SYSTEM BOOT SUCCESSFUL [VER 14.0_r34]',
      type: 'system',
      timestamp: getPreciseTimestamp()
    },
    {
      id: 'init-2',
      text: 'اكتب "help" لعرض المساعدة وقائمة الأوامر الأساسية لـ Android & ADB.',
      type: 'success',
      timestamp: getPreciseTimestamp()
    },
    {
      id: 'init-3',
      text: 'أو استخدم القائمة الجانبية لحقن واختيار الأوامر الجاهزة بنقرة واحدة!',
      type: 'warning',
      timestamp: getPreciseTimestamp()
    },
    {
      id: 'init-banner',
      text: '       _  _  _  _       _ \n  _ _ | || || || | _ _ | |\n / _` || || || || / _` || |\n| (_| || || || || | (_| || |\n \\__,_||_||_||_||_| \\__,_||_|\n   Android Bash Emulator v2.0 - Grey Concept\n   اكتب neofetch لتفاصيل الجهاز',
      type: 'ascii',
      timestamp: getPreciseTimestamp()
    }
  ]);
  
  // Terminal Command History for Up/Down Arrows
  const [cmdHistory, setCmdHistory] = useState<string[]>(['help', 'neofetch', 'logcat', 'su']);
  const [historyIdx, setHistoryIdx] = useState<number>(-1);
  
  // Editor (nano) State
  const [editingFile, setEditingFile] = useState<{ filename: string; path: string; content: string } | null>(null);
  
  // Custom Aliases State
  const [aliases, setAliases] = useState<Record<string, string>>({
    c: 'clear',
    sys: 'neofetch',
    battery: 'dumpsys battery',
    ll: 'ls'
  });

  // List of installed packages
  const [installedPackages, setInstalledPackages] = useState<string[]>([
    'com.termux',
    'com.android.chrome',
    'com.google.android.youtube',
    'com.whatsapp',
    'com.instagram.android',
    'com.spotify.music',
    'com.android.settings',
    'com.google.android.gms'
  ]);

  // File system upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = (event.target?.result as string) || '';
      // Create node in path "/"
      const result = createNodeInPath(vfs, '/', file.name, 'file', content);
      if (result.success) {
        setVfs(result.root);
        setHistory(prev => [
          ...prev,
          {
            id: 'upload-' + Math.random(),
            text: `[UPLOADER] تم رفع الملف "${file.name}" بنجاح وحفظه في مجلد الجذر (/)! حجم الملف: ${file.size} بايت.`,
            type: 'success',
            timestamp: getPreciseTimestamp()
          }
        ]);
      } else {
        setHistory(prev => [
          ...prev,
          {
            id: 'upload-err-' + Math.random(),
            text: `[UPLOADER] خطأ في رفع الملف: ${result.error}`,
            type: 'error',
            timestamp: getPreciseTimestamp()
          }
        ]);
      }
    };
    reader.onerror = () => {
      alert('خطأ أثناء قراءة الملف المرفوع!');
    };
    reader.readAsText(file);
  };
  
  // Long running streams (logcat / reboot sequence)
  const [isLogcatActive, setIsLogcatActive] = useState<boolean>(false);
  const [rebooting, setRebooting] = useState<boolean>(false);
  const [rebootProgress, setRebootProgress] = useState<number>(0);
  const [rebootLogs, setRebootLogs] = useState<string[]>([]);
  
  // DOM References
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-focus input
  useEffect(() => {
    if (!editingFile && !rebooting && inputRef.current) {
      inputRef.current.focus();
    }
  }, [editingFile, rebooting]);

  // Scroll to bottom whenever history changes
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history, isLogcatActive, editingFile]);

  // Handle Logcat simulated loop
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isLogcatActive) {
      const logcatLogs = [
        'D/BatteryService( 1502): updateBatteryStateLocked: level=84, temp=294, voltage=3822',
        'I/ActivityManager( 1502): START u0 {act=android.intent.action.MAIN cmp=com.termux/.MainActivity}',
        'D/NetworkController( 2101): onWifiSignalChanged: level=4, connected=true',
        'W/ziparchive( 2143): Unable to open \'/data/app/com.termux/base.apk\'',
        'V/WindowManager( 1502): Setup window frame: com.termux/com.termux.MainActivity',
        'I/PackageManager( 1502): Checking signature permissions for UID 10243',
        'D/InputDispatcher( 1502): Delivered motion event touch down at (482.0, 1020.2)',
        'E/SurfaceFlinger(  812): Failed to find a compatible pixel format config, error = BAD_CONFIG',
        'I/chatty  (  812): expire 4 lines on uid 1000',
        'W/ContextImpl( 2143): Calling a method in the system process with a null Context',
        'I/ActivityManager( 1502): Displayed com.termux/.MainActivity: +450ms',
        'D/audio_hw_primary(  744): out_set_parameters: enter: usecase 1: devices 0x2',
        'D/dalvikvm( 2143): GC_CONCURRENT freed 384K, 12% free 8214K/9312K, paused 2ms+3ms',
        'I/auditd  (  503): type=1400 audit(172291.124:43): avc: granted { read } path="/sys/class/power_supply/battery/capacity"'
      ];

      interval = setInterval(() => {
        const randomLog = logcatLogs[Math.floor(Math.random() * logcatLogs.length)];
        const timeStr = getPreciseTimestamp();
        setHistory(prev => [
          ...prev, 
          {
            id: 'logcat-' + Math.random(),
            text: `[${timeStr}] ${randomLog}`,
            type: 'system',
            timestamp: timeStr
          }
        ]);
      }, 500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isLogcatActive]);

  // Handle reboot simulation loading bar
  useEffect(() => {
    let timer: NodeJS.Timeout | null = null;
    if (rebooting) {
      const bootStages = [
        { progress: 10, log: 'Initializing bootloaders v4.12...' },
        { progress: 25, log: '[   0.000000] Linux system kernel v6.1.57 loading...' },
        { progress: 40, log: '[   0.459021] Mounting /system read-only file systems...' },
        { progress: 55, log: '[   1.120294] Initializing Android Zygote processes...' },
        { progress: 70, log: '[   2.112003] Loading Android Package Manager & core overlays...' },
        { progress: 85, log: '[   2.895012] Binding terminal services on port 3000...' },
        { progress: 100, log: 'Android Termux system successfully loaded!' }
      ];

      timer = setInterval(() => {
        setRebootProgress(prev => {
          const next = prev + 5;
          const stage = bootStages.find(s => next >= s.progress && next - 5 < s.progress);
          if (stage) {
            setRebootLogs(l => [...l, stage.log]);
          }
          if (next >= 100) {
            if (timer) clearInterval(timer);
            setTimeout(() => {
              setRebooting(false);
              setHistory(prevHist => [
                ...prevHist,
                {
                  id: 'reboot-done',
                  text: 'إعادة التشغيل تمت بنجاح! تم تنظيف الجلسة واستعادة سطر الأوامر.',
                  type: 'success',
                  timestamp: getPreciseTimestamp()
                }
              ]);
            }, 600);
            return 100;
          }
          return next;
        });
      }, 200);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [rebooting]);

  // Execute Reboot Command
  const triggerReboot = () => {
    setRebooting(true);
    setRebootProgress(0);
    setRebootLogs(['سحب طاقة الجهاز... إعادة تفريغ الذاكرة المؤقتة.']);
    setVfs(getInitialVFS()); // reset virtual files
    setCurrentPath('/sdcard/Download');
    setIsRoot(false);
    setIsLogcatActive(false);
  };

  // Process Interactive Commands
  const queryLocalhostServer = (urlStr: string) => {
    let cleanUrl = urlStr.replace(/^(https?:\/\/)/, '');
    const firstSlash = cleanUrl.indexOf('/');
    let hostPort = firstSlash === -1 ? cleanUrl : cleanUrl.substring(0, firstSlash);
    let requestPath = firstSlash === -1 ? '' : cleanUrl.substring(firstSlash);
    
    const colonIdx = hostPort.indexOf(':');
    const host = colonIdx === -1 ? hostPort : hostPort.substring(0, colonIdx);
    const portStr = colonIdx === -1 ? '80' : hostPort.substring(colonIdx + 1);
    const portNum = parseInt(portStr, 10);
    
    if (host !== 'localhost' && host !== '127.0.0.1' && host !== '0.0.0.0') {
      return { success: false, error: 'unknown_host' };
    }
    
    const server = runningServers.find(srv => srv.port === portNum);
    if (!server) {
      return { success: false, error: 'connection_refused' };
    }
    
    const finalVfsPath = resolvePath(server.path, requestPath);
    const node = findNodeByPath(vfs, finalVfsPath);
    
    if (!node) {
      return {
        success: true,
        status: 404,
        content: `<!DOCTYPE html>\n<html>\n<head><title>404 Not Found</title></head>\n<body>\n<h1>404 Not Found</h1>\n<p>The requested URL ${requestPath} was not found on this simulated server.</p>\n</body>\n</html>`,
        contentType: 'text/html'
      };
    }
    
    if (node.type === 'file') {
      return {
        success: true,
        status: 200,
        content: node.content || '',
        contentType: finalVfsPath.endsWith('.html') ? 'text/html' : 'text/plain'
      };
    }
    
    const indexNode = node.children ? node.children['index.html'] : undefined;
    if (indexNode && indexNode.type === 'file') {
      return {
        success: true,
        status: 200,
        content: indexNode.content || '',
        contentType: 'text/html'
      };
    }
    
    let listItemsHTML = '';
    if (node.children) {
      const sortedKeys = Object.keys(node.children).sort();
      for (const key of sortedKeys) {
        const child = node.children[key];
        const isDir = child.type === 'dir';
        listItemsHTML += `  <li><a href="${key}${isDir ? '/' : ''}">${key}${isDir ? '/' : ''}</a></li>\n`;
      }
    }
    
    const dirListingHTML = `<!DOCTYPE html>\n<html>\n<head>\n  <meta charset="utf-8">\n  <title>Directory listing for ${requestPath || '/'}</title>\n  <style>\n    body { font-family: monospace; padding: 20px; background-color: #0c0c0e; color: #d4d4d8; }\n    a { color: #38bdf8; text-decoration: none; }\n    a:hover { text-decoration: underline; }\n    ul { list-style-type: none; padding-left: 0; }\n    li { padding: 4px 0; border-bottom: 1px solid #27272a; }\n  </style>\n</head>\n<body>\n  <h2>Directory listing for ${requestPath || '/'}</h2>\n  <hr>\n  <ul>\n    ${requestPath && requestPath !== '/' ? '<li><a href="../">../ (Mather Directory)</a></li>\n' : ''}${listItemsHTML}  </ul>\n  <hr>\n  <p style="font-size: 11px; color: #71717a;">Simulated Python/3.10.6 SimpleHTTP Server</p>\n</body>\n</html>`;
    
    return {
      success: true,
      status: 200,
      content: dirListingHTML,
      contentType: 'text/html'
    };
  };

  const handleExecuteCommand = (commandStr: string) => {
    const trimmed = commandStr.trim();
    if (!trimmed) return;

    // Add to history list
    const newHistItem: TerminalHistoryItem = {
      id: 'usr-' + Math.random(),
      text: `${pythonReplActive ? '>>>' : isRoot ? 'root:/ #' : 'android:' + currentPath + ' $'} ${trimmed}`,
      type: 'input',
      timestamp: getPreciseTimestamp()
    };
    
    setCmdHistory(prev => {
      const clean = prev.filter(c => c !== trimmed);
      return [...clean, trimmed];
    });
    setHistoryIdx(-1);

    // Stop logcat if active on any key stroke command
    if (isLogcatActive) {
      setIsLogcatActive(false);
      setHistory(prev => [
        ...prev,
        {
          id: 'logcat-stop',
          text: 'تم إيقاف Logcat بنجاح.',
          type: 'warning',
          timestamp: getPreciseTimestamp()
        }
      ]);
      return;
    }

    if (pythonReplActive) {
      if (trimmed === 'exit()' || trimmed === 'quit()' || trimmed === 'exit' || trimmed === 'quit') {
        setPythonReplActive(false);
        setHistory(prev => [
          ...prev,
          newHistItem,
          {
            id: 'py-exit-' + Math.random(),
            text: 'Leaving Python interactive shell.',
            type: 'system',
            timestamp: getPreciseTimestamp()
          }
        ]);
        return;
      }

      let responseText = '';
      let responseType: 'success' | 'system' | 'error' | 'warning' = 'success';

      if (trimmed.startsWith('print(')) {
        const match = trimmed.match(/^print\((['"])(.*?)\1\)$/);
        if (match) {
          responseText = match[2];
        } else {
          const exprMatch = trimmed.match(/^print\((.*?)\)$/);
          if (exprMatch) {
            const expr = exprMatch[1].trim();
            if (pythonEnv[expr] !== undefined) {
              responseText = String(pythonEnv[expr]);
            } else {
              try {
                const evalVal = Function(`"use" ; return (${expr})`)();
                responseText = String(evalVal);
              } catch (e) {
                responseText = `NameError: name '${expr}' is not defined`;
                responseType = 'error';
              }
            }
          } else {
            responseText = '  File "<stdin>", line 1\n    print(' + trimmed.substring(6) + '\nSyntaxError: unexpected EOF while parsing';
            responseType = 'error';
          }
        }
      } else if (trimmed.includes('=')) {
        const parts = trimmed.split('=');
        if (parts.length === 2) {
          const varName = parts[0].trim();
          const varValExpr = parts[1].trim();
          if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(varName)) {
            try {
              const resolvedVal = Function(`"use" ; return (${varValExpr})`)();
              setPythonEnv(prev => ({ ...prev, [varName]: resolvedVal }));
              responseText = '';
            } catch (e) {
              responseText = `SyntaxError: invalid syntax in expression "${varValExpr}"`;
              responseType = 'error';
            }
          } else {
            responseText = `SyntaxError: cannot assign to operator or invalid identifier "${varName}"`;
            responseType = 'error';
          }
        } else {
          responseText = 'SyntaxError: multiple assignments not fully supported in simulation REPL';
          responseType = 'error';
        }
      } else if (trimmed === 'help()' || trimmed === 'help') {
        responseText = 'Type help() for interactive help, or exit() to leave the Python interpreter.';
        responseType = 'system';
      } else {
        if (pythonEnv[trimmed] !== undefined) {
          responseText = String(pythonEnv[trimmed]);
        } else {
          try {
            const resultValue = Function(`"use" ; return (${trimmed})`)();
            if (resultValue !== undefined) {
              responseText = String(resultValue);
            }
          } catch (e) {
            responseText = `NameError: name '${trimmed}' is not defined or invalid syntax`;
            responseType = 'error';
          }
        }
      }

      setHistory(prev => {
        const nextHist = [...prev, newHistItem];
        if (responseText) {
          nextHist.push({
            id: 'py-res-' + Math.random(),
            text: responseText,
            type: responseType,
            timestamp: getPreciseTimestamp()
          });
        }
        return nextHist;
      });
      return;
    }

    // Split logical chained commands
    const subCommands = splitChainedCommands(trimmed);

    let vfsLocal = vfs;
    let currentPathLocal = currentPath;
    let isRootLocal = isRoot;
    let aliasesLocal = aliases;
    let historyLocal = [
      ...history,
      newHistItem
    ];

    let lastSuccess = true;

    for (const item of subCommands) {
      if (item.operator === '&&' && !lastSuccess) {
        continue;
      }
      if (item.operator === '||' && lastSuccess) {
        continue;
      }

      const runSingleCommand = (subCommandStr: string): boolean => {
        let vfs = vfsLocal;
        let currentPath = currentPathLocal;
        let isRoot = isRootLocal;
        let aliases = aliasesLocal;
        let commandFailed = false;

        const setVfs = (updater: any) => {
          if (typeof updater === 'function') {
            vfs = updater(vfs);
          } else {
            vfs = updater;
          }
          vfsLocal = vfs;
        };

        const setCurrentPath = (updater: any) => {
          if (typeof updater === 'function') {
            currentPath = updater(currentPath);
          } else {
            currentPath = updater;
          }
          currentPathLocal = currentPath;
        };

        const setIsRoot = (updater: any) => {
          if (typeof updater === 'function') {
            isRoot = updater(isRoot);
          } else {
            isRoot = updater;
          }
          isRootLocal = isRoot;
        };

        const setAliases = (updater: any) => {
          if (typeof updater === 'function') {
            aliases = updater(aliases);
          } else {
            aliases = updater;
          }
          aliasesLocal = aliases;
        };

        const setHistory = (updater: any) => {
          if (typeof updater === 'function') {
            historyLocal = updater(historyLocal);
          } else {
            historyLocal = updater;
          }
        };

        // Pipe parsing supporting piped grep
        const pipeParts = subCommandStr.split('|').map(p => p.trim());
        const hasPipeGrep = pipeParts.length > 1 && pipeParts[1].toLowerCase().startsWith('grep');
        let grepPatternString = '';
        let grepCaseInsensitive = false;
        let grepShowLineNumbers = false;

        if (hasPipeGrep) {
          const grepArgs = pipeParts[1].split(' ').filter(Boolean);
          let flagsIdx = 1;
          while (flagsIdx < grepArgs.length && grepArgs[flagsIdx].startsWith('-')) {
            const flag = grepArgs[flagsIdx];
            if (flag.includes('i')) grepCaseInsensitive = true;
            if (flag.includes('n')) grepShowLineNumbers = true;
            flagsIdx++;
          }
          if (flagsIdx < grepArgs.length) {
            grepPatternString = grepArgs.slice(flagsIdx).join(' ').replace(/"/g, '');
          }
        }

        const commandToProcess = pipeParts[0];
        let args = commandToProcess.split(' ').filter(Boolean);
        
        if (args.length === 0) return true;

        // Check & expand aliases iteratively (up to 5 recursions to avoid infinite loops)
        let expansionCount = 0;
        while (args.length > 0 && expansionCount < 5) {
          const maybeAlias = args[0].toLowerCase();
          if (aliases[maybeAlias]) {
            const aliasValue = aliases[maybeAlias];
            const aliasParts = aliasValue.split(' ').filter(Boolean);
            args = [...aliasParts, ...args.slice(1)];
            expansionCount++;
          } else {
            break;
          }
        }

        if (args.length === 0) return true;
        const cmd = args[0].toLowerCase();

        const timestamp = getPreciseTimestamp();

        const writeOutput = (text: string, type: TerminalHistoryItem['type'] = 'output') => {
          if (type === 'error') {
            commandFailed = true;
          }
          if (hasPipeGrep && grepPatternString) {
            const lines = text.split('\n');
            const matchedLines = lines.filter((line) => {
              let isMatch = false;
              if (grepCaseInsensitive) {
                isMatch = line.toLowerCase().includes(grepPatternString.toLowerCase());
              } else {
                isMatch = line.includes(grepPatternString);
              }
              return isMatch;
            });

            if (matchedLines.length > 0) {
              const formattedLines = matchedLines.map((line, index) => {
                return grepShowLineNumbers ? `${index + 1}:${line}` : line;
              });
              setHistory((prev: any) => [...prev, { id: 'out-' + Math.random(), text: formattedLines.join('\n'), type, timestamp }]);
            } else {
              setHistory((prev: any) => [...prev, { id: 'out-' + Math.random(), text: `(لم يتم العثور على أسطر تطابق النمط "${grepPatternString}")`, type: 'warning', timestamp }]);
            }
          } else {
            setHistory((prev: any) => [...prev, { id: 'out-' + Math.random(), text, type, timestamp }]);
          }
        };

        switch (cmd) {
      case 'clear':
        setHistory([]);
        break;

      case 'history':
        {
          const currentList = cmdHistory.includes(trimmed) 
            ? [...cmdHistory.filter(c => c !== trimmed), trimmed]
            : [...cmdHistory, trimmed];
          
          if (currentList.length === 0) {
            writeOutput('سجل الأوامر فارغ حالياً.', 'warning');
          } else {
            const historyStr = currentList
              .map((cmdText, idx) => `  ${String(idx + 1).padEnd(4, ' ')}  ${cmdText}`)
              .join('\n');
            writeOutput(
              `سجل الأوامر للجلسة الحالية [Total: ${currentList.length}]:\n` +
              `-------------------------------------------------------\n` +
              historyStr,
              'success'
            );
          }
        }
        break;

      case 'man':
        {
          if (args.length < 2) {
            // Show usage & sorted command manual categories
            const sortedCommands = Object.keys(commandHints).sort();
            const colWidth = 15;
            let commandsGrid = '  ';
            let lineLen = 2; // initial indentation
            
            for (const cmdName of sortedCommands) {
              const paddedName = cmdName.padEnd(colWidth);
              if (lineLen + colWidth > 70) {
                commandsGrid += '\n  ' + paddedName;
                lineLen = 2 + colWidth;
              } else {
                commandsGrid += paddedName;
                lineLen += colWidth;
              }
            }

            writeOutput(
              `دليل واستخدام الأوامر (Android Manual Page Helper)\n` +
              `=======================================================\n` +
              `الاستخدام: man [الأمر]\n` +
              `مثال: man grep\n\n` +
              `الأوامر المتاحة في الدليل للتصفح:\n` +
              commandsGrid + `\n\n` +
              `-------------------------------------------------------\n` +
              `للحصول على شرح تفصيلي لأي أمر، اكتب: man followed_by_command_name`,
              'success'
            );
          } else {
            const targetCmd = args[1].toLowerCase();
            const rawHint = commandHints[targetCmd];
            if (rawHint !== undefined) {
              const match = rawHint.match(/^\s*(.*?)\s*\((.*?)\)\s*$/);
              let synopsis = '';
              let description = '';
              if (match) {
                synopsis = match[1].trim();
                description = match[2].trim();
              } else {
                description = rawHint.trim();
              }

              writeOutput(
                `دليل استخدام الأندرويد (BASH MANUAL - PAGE: ${targetCmd})\n` +
                `=======================================================\n` +
                `الاسم والمهمة (NAME & PURPOSE):\n` +
                `   ${targetCmd} - ${description}\n\n` +
                `طريقة وصيغة الاستعمال (SYNOPSIS):\n` +
                `   ${targetCmd}${synopsis ? ' ' + synopsis : ''}\n` +
                `=======================================================\n` +
                `ملاحظة: للحصول على قائمة عامة بكافة المساعدات، اكتب help أو man`,
                'success'
              );
            } else {
              writeOutput(
                `خطأ: لا يوجد دليل كتيب (man page) متوفر للأمر: "${targetCmd}"\n` +
                `جرب كتابة "man" بمفرده لعرض قائمة بكافة الأوامر الموثقة المتاحة.`,
                'error'
              );
            }
          }
        }
        break;

      case 'help':
      case 'commands':
        writeOutput(
          'أهلاً بك في نظام سطر أوامر أندرويد لـ AI Studio (نسخة أسود ورمادي)\n' +
          '=======================================================\n' +
          'الأوامر الأساسية المدعومة في المحاكي التفاعلي:\n' +
          '  help      : عرض قائمة المساعدة الحالية.\n' +
          '  man [cmd] : عرض دليل صفحة كتيب التعليمات المتقدم للأمر المحدد.\n' +
          '  neofetch  : عرض مواصفات الهاتف وشعار الأندرويد.\n' +
          '  ls        : عرض الملفات والمجلدات الحالية.\n' +
          '  cd [path] : الانتقال لمجلد أو مسار آخر (مثال: cd /sdcard).\n' +
          '  pwd       : معرفة وطباعة مسار المجلد الحالي (مكانك الحالي).\n' +
          '  mkdir [d] : إنشاء مجلد جديد (مثال: mkdir MyFolder).\n' +
          '  touch [f] : إنشاء ملف نصي فارغ (مثال: touch settings.conf).\n' +
          '  edit [f]  : (أو nano) لفتح محرر النصوص الرائع لتعديل وحفظ الملفات.\n' +
          '  cat [f]   : قراءة وعرض محتوى ملف نصي.\n' +
          '  tail [f]  : عرض نهاية الملف النصي (مثال: tail -n 5 note.txt).\n' +
          '  find [p]  : الملاحة والبحث التكراري (مثال: find . -name "*.txt").\n' +
          '  echo [t]  : كتابة نصوص وحفظها بالملف (echo "hi" > text.txt).\n' +
          '  rm [f]    : حذف ملف أو مجلد (-rf للحذف بالقوة للمجلدات).\n' +
          '  id        : عرض معرف الهوية الحالي للأندرويد والمجموعات المتاحة.\n' +
          '  login:root: تسجيل دخول سريع ومباشر بصفة المستخدم الخارق root.\n' +
          '  su        : الانتقال إلى وضع الروت الخارق (يتغير prefix إلى #).\n' +
          '  getprop   : قراءة خصائص النظام للأندرويد (getprop ro.product.model).\n' +
          '  dumpsys   : إحصائيات الأجهزة والبطارية (dumpsys battery).\n' +
          '  wm        : التحكم بحجم ودقة الشاشة (wm size).\n' +
          '  logcat    : بدء بث حي ومباشر لسجلات النظام وهفوات التطبيقات والبرمجة.\n' +
          '  pm        : إدارة وتثبيت الحزم والتطبيق (pm list packages).\n' +
          '  ps / top  : عرض قائمة بالعمليات الحالية والمهام البرمجية للـ CPU.\n' +
          '  reboot    : إعادة تشغيل الهاتف بالكامل ومحاكاة شاشة الإقلاع.\n' +
          '  history   : عرض قائمة بكافة الأوامر التي قمت بتنفيذها في الجلسة.\n' +
          '  clear     : تنظيف تاريخ شاشة الطرفية.\n' +
          '=======================================================\n' +
          'نصيحة: استخدم اللوحة والمستندات على يسار الشاشة لحقن الأوامر التلقائية للمبتدئين!',
          'success'
        );
        break;

      case 'about':
        writeOutput(
          '=======================================================\n' +
          'تمت البرمجة بواسطة مستور الحربي\n' +
          'by mastoor alharbi\n' +
          '=======================================================\n' +
          'Android Terminal Bash Simulator & ADB Interactive Manual\n' +
          'Developed with precision using minimalist dark greyscale aesthetics.',
          'success'
        );
        break;

      case 'alias':
        {
          const aliasStr = commandToProcess.substring(commandToProcess.toLowerCase().indexOf('alias') + 5).trim();
          
          if (!aliasStr) {
            const list = Object.entries(aliases)
              .map(([name, value]) => `alias ${name}='${value}'`)
              .sort()
              .join('\n');
            writeOutput(list || '(لا توجد اختصارات مسجلة حالياً)', 'success');
            break;
          }

          const eqIdx = aliasStr.indexOf('=');
          if (eqIdx !== -1) {
            const aliasName = aliasStr.substring(0, eqIdx).trim().toLowerCase();
            let aliasVal = aliasStr.substring(eqIdx + 1).trim();
            
            if ((aliasVal.startsWith("'") && aliasVal.endsWith("'")) || (aliasVal.startsWith('"') && aliasVal.endsWith('"'))) {
              aliasVal = aliasVal.substring(1, aliasVal.length - 1);
            }
            
            if (!aliasName) {
              writeOutput('خطأ في بناء الأمر: اسم الاختصار فارغ.', 'error');
            } else {
              setAliases(prev => ({ ...prev, [aliasName]: aliasVal }));
              writeOutput(`تم إنشاء الاختصار بنجاح: alias ${aliasName}='${aliasVal}'`, 'success');
            }
          } else {
            const aliasName = aliasStr.toLowerCase();
            if (aliases[aliasName]) {
              writeOutput(`alias ${aliasName}='${aliases[aliasName]}'`, 'success');
            } else {
              writeOutput(`alias: ${aliasName}: not found`, 'error');
            }
          }
        }
        break;

      case 'unalias':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد اسم الاختصار لحذفه. مثال: unalias c', 'warning');
            break;
          }
          const name = args[1].toLowerCase();
          if (aliases[name]) {
            setAliases(prev => {
              const updated = { ...prev };
              delete updated[name];
              return updated;
            });
            writeOutput(`تم حذف الاختصار "${name}" بنجاح.`, 'success');
          } else {
            writeOutput(`unalias: ${name}: not found`, 'error');
          }
        }
        break;

      case 'neofetch':
        const art = 
`         .---.        localhost [Pixel 8 Pro]
        /     \\       -----------------------
       | () () |      OS: Android 14 (UpsideDownCake)
        \\  ^  /       Kernel: v6.1.57-android14-perf
     .-` + '`' + `  '-'  ` + '`' + `-.    Uptime: 4 hours, 32 mins
    /             \\   Shell: Bash Termux Simulator
   |   |       |   |  CPU: Google Tensor G3 (9 cores)
   |   |_______|   |  RAM: 7.42 GB / 12.00 GB (61%)
   |               |  Storage: 124.2 GB / 256.0 GB (48%)
   |               |  Resolution: 1344 x 2992 @ 120Hz
                      Root status: ${isRoot ? 'GRANTED / ROOT USER' : 'Locked / normal user'}`;
        writeOutput(art, 'ascii');
        break;

      case 'dir':
      case 'ls':
        {
          let targetPathToCheck = currentPath;
          if (args[1] && !args[1].startsWith('-')) {
            targetPathToCheck = resolvePath(currentPath, args[1]);
          }

          const isTargetSystem = targetPathToCheck === '/' || targetPathToCheck.startsWith('/system') || targetPathToCheck.startsWith('/etc') || targetPathToCheck.startsWith('/data');
          if (isTargetSystem && !isRoot) {
            writeOutput(`[sh] ls: Permission denied (أنت بحاجة لصلاحيات الروت لعرض محتويات النظام الجذرية. اكتب su أولاً لتصبح SuperUser!)`, 'error');
            break;
          }

          const targetNode = findNodeByPath(vfs, targetPathToCheck);
          if (targetNode && targetNode.type === 'dir' && targetNode.children) {
            const keys = Object.keys(targetNode.children);
            if (keys.length === 0) {
              writeOutput('(المجلد فارغ حالياً)');
            } else {
              if (cmd === 'dir') {
                const formattedList = keys.map(k => {
                  const nodeItem = targetNode.children![k];
                  const isDir = nodeItem.type === 'dir';
                  const dateStr = new Date().toLocaleDateString();
                  const sizeStr = isDir ? '<DIR>' : `${(nodeItem.content || '').length} Bytes`;
                  return `${dateStr}  ${sizeStr.padEnd(12)}  ${isDir ? '📁' : '📄'} ${k}`;
                }).join('\n');
                writeOutput(`محتويات المجلد الحالي: ${targetPathToCheck}\n=======================================================\n${formattedList}\n=======================================================\nإجمالي العناصر: ${keys.length}`, 'success');
              } else {
                const formattedList = keys.map(k => {
                  const isDir = targetNode.children![k].type === 'dir';
                  return isDir ? `📂 ${k}/  ` : `📄 ${k}  `;
                }).join('\n');
                writeOutput(formattedList, 'success');
              }
            }
          } else {
            writeOutput('خطأ: تعذر فحص المجلد المطلوب.', 'error');
          }
        }
        break;

      case 'pwd':
        writeOutput(currentPath);
        break;

      case 'cd':
        {
          let target = args[1] || '/sdcard';
          if (target === '~') target = '/sdcard';
          const resolved = resolvePath(currentPath, target);

          const isTargetSystem = resolved === '/' || resolved.startsWith('/system') || resolved.startsWith('/etc') || resolved.startsWith('/data');
          if (isTargetSystem && !isRoot) {
            writeOutput(`[sh] cd: Permission denied (الدخول لمجلدات الجذر مثل "${target}" يتطلب صلاحية الروت. اكتب su أولاً!)`, 'error');
            break;
          }

          const destinationNode = findNodeByPath(vfs, resolved);
          if (destinationNode) {
            if (destinationNode.type === 'dir') {
              setCurrentPath(resolved);
            } else {
              writeOutput(`خطأ: ${target} ليس مجلداً، بل ملف!`, 'error');
            }
          } else {
            writeOutput(`خطأ: المجلد غير موجود: ${target}`, 'error');
          }
        }
        break;

      case 'mv':
        {
          if (args.length < 3) {
            writeOutput('تنبيه: حدد الملف المصدر والهدف لحركته أو تعديل اسمه. مثال: mv file.txt file_old.txt', 'warning');
            break;
          }
          const src = args[1];
          const dest = args[2];
          
          const srcResolved = resolvePath(currentPath, src);
          const srcNode = findNodeByPath(vfs, srcResolved);
          if (!srcNode) {
            writeOutput(`خطأ: الملف المصدر غير موجود: ${src}`, 'error');
            break;
          }
          
          const removeResult = removeNodeFromPath(vfs, currentPath, src);
          if (!removeResult.success) {
            writeOutput(`خطأ أثناء النقل: ${removeResult.error}`, 'error');
            break;
          }
          
          const createResult = createNodeInPath(removeResult.root, currentPath, dest, srcNode.type, srcNode.content || '');
          if (createResult.success) {
            setVfs(createResult.root);
            writeOutput(`تم نقل/إعادة تسمية "${src}" إلى "${dest}" بنجاح!`, 'success');
          } else {
            writeOutput(`خطأ أثناء محاولة وضع الملف في المجلد الجديد: ${createResult.error}`, 'error');
          }
        }
        break;

      case 'cp':
        {
          if (args.length < 3) {
            writeOutput('تنبيه: حدد الملف الأساسي ومسار النسخة الجديدة. مثال: cp welcome.txt welcome_backup.txt', 'warning');
            break;
          }
          const src = args[1];
          const dest = args[2];
          
          const srcResolved = resolvePath(currentPath, src);
          const srcNode = findNodeByPath(vfs, srcResolved);
          if (!srcNode) {
            writeOutput(`خطأ: الملف المصدر غير موجود: ${src}`, 'error');
            break;
          }
          
          if (srcNode.type === 'dir') {
            writeOutput('تنبيه: نسخ المجلدات غير مدعوم حالياً بشكل مباشر، يمكنك نسخ الملفات فقط.', 'warning');
            break;
          }
          
          const createResult = createNodeInPath(vfs, currentPath, dest, 'file', srcNode.content || '');
          if (createResult.success) {
            setVfs(createResult.root);
            writeOutput(`تم نسخ الملف بنجاح إلى: ${dest}`, 'success');
          } else {
            writeOutput(`خطأ في عملية النسخ: ${createResult.error}`, 'error');
          }
        }
        break;

      case 'get':
      case 'wget':
      case 'curl':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد قيمة التحميل أو الرابط المطلوب. مثال:\n' +
                        '  get https://example.com/api/test.json\n' +
                        '  get test_file.txt (لتحميل ملف محلي إلى كمبيوترك الخارجي)', 'warning');
            break;
          }
          const urlOrFile = args[1];
          const isLocalhost = urlOrFile.includes('localhost') || urlOrFile.includes('127.0.0.1') || urlOrFile.includes('0.0.0.0');
          if (isLocalhost) {
            const res = queryLocalhostServer(urlOrFile);
            if (res.success) {
              writeOutput(
                `HTTP/1.1 ${res.status} OK\n` +
                `Content-Type: ${res.contentType}\n` +
                `Content-Length: ${res.content.length}\n` +
                `Connection: close\n\n` +
                `${res.content}`,
                'success'
              );
            } else {
              if (res.error === 'connection_refused') {
                writeOutput(`curl: (7) Failed to connect to local port: Connection refused`, 'error');
              } else {
                writeOutput(`curl: (6) Could not resolve host: ${urlOrFile}`, 'error');
              }
            }
            break;
          }
          if (urlOrFile.startsWith('http://') || urlOrFile.startsWith('https://')) {
            writeOutput(`[GET] جاري تهيئة الاتصال بالخادم: ${urlOrFile}...`, 'system');
            
            let downloadableName = 'index.html';
            try {
              const urlParsed = new URL(urlOrFile);
              const pathname = urlParsed.pathname;
              const lastPart = pathname.substring(pathname.lastIndexOf('/') + 1);
              if (lastPart && lastPart.includes('.')) {
                downloadableName = lastPart;
              }
            } catch (e) {
              downloadableName = 'downloaded.txt';
            }
            
            writeOutput(`[GET] جاري تحميل الملف "${downloadableName}"...`, 'system');
            
            setTimeout(() => { writeOutput(`[GET] ------------------------- [25%] 512KB/s`); }, 200);
            setTimeout(() => { writeOutput(`[GET] =============------------ [55%] 820KB/s`); }, 500);
            setTimeout(() => { writeOutput(`[GET] =======================-- [90%] 1.1MB/s`); }, 800);
            setTimeout(() => { 
              const simHTML = `<!DOCTYPE html>\n<html>\n<head>\n  <title>Simulated Content from ${urlOrFile}</title>\n</head>\n<body>\n  <p>Downloaded via terminal "get" command successfully on ${new Date().toLocaleString()}</p>\n</body>\n</html>`;
              const result = createNodeInPath(vfs, currentPath, downloadableName, 'file', simHTML);
              if (result.success) {
                setVfs(result.root);
                writeOutput(`[GET] تم التحميل والحفظ في المسار الحالي بنجاح! اسم الملف: ${downloadableName}`, 'success');
              } else {
                writeOutput(`[GET] خطأ في كتابة الملف: ${result.error}`, 'error');
              }
            }, 1000);
          } else {
            const resolvedPath = resolvePath(currentPath, urlOrFile);
            const node = findNodeByPath(vfs, resolvedPath);
            if (node && node.type === 'file') {
              writeOutput(`[GET] جاري إرسال وتنزيل الملف الداخلي "${urlOrFile}" إلى جهازك الخارجي...`, 'success');
              const blob = new Blob([node.content || ''], { type: 'text/plain' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = urlOrFile;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            } else {
              writeOutput(`خطأ: لم يتم العثور على ملف محلي باسم "${urlOrFile}" في المجلد لتنزيله.`, 'error');
            }
          }
        }
        break;

      case 'apt':
      case 'apt-get':
      case 'apt-install':
        {
          const isInstall = cmd === 'apt-install' || (args[0] === 'apt' && args[1] === 'install') || (args[0] === 'apt-get' && args[1] === 'install');
          const isUpdate = (args[0] === 'apt' && args[1] === 'update') || (args[0] === 'apt-get' && args[1] === 'update');
          const isUpgrade = (args[0] === 'apt' && args[1] === 'upgrade') || (args[0] === 'apt-get' && args[1] === 'upgrade');
          
          if (isUpdate) {
            writeOutput(
              'Hit:1 https://deb.debian.org/debian buster InRelease\n' +
              'Get:2 https://deb.debian.org/debian buster-updates InRelease [121 kB]\n' +
              'Reading package lists... Done\n' +
              'Building dependency tree... Done\n' +
              'All current developer packages are simulated to be up-to-date.',
              'success'
            );
          } else if (isUpgrade) {
            writeOutput('Calculating upgrade... Done\n0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.', 'success');
          } else if (isInstall) {
            const startIndex = cmd === 'apt-install' ? 1 : 2;
            const pkgName = args[startIndex];
            if (!pkgName) {
              writeOutput('تنبيه: الرجاء تحديد حزمة لتثبيتها باستخدام Apt. مثال: apt install clang', 'warning');
            } else {
              if (pkgName.toLowerCase() === 'python' || pkgName.toLowerCase() === 'python3') {
                setIsPythonInstalled(true);
              }
              writeOutput(
                `Reading package lists... Done\n` +
                `Building dependency tree... Done\n` +
                `The following NEW packages will be installed:\n` +
                `  ${pkgName}\n` +
                `0 upgraded, 1 newly installed, 0 to remove.\n` +
                `Need to get 1,402 kB of archives.\n` +
                `Get:1 https://deb.debian.org/debian ${pkgName} [1,402 kB]\n` +
                `Selecting previously unselected package ${pkgName}...\n` +
                `Preparing to unpack .../${pkgName}_arm64.deb ...\n` +
                `Unpacking ${pkgName} ...\n` +
                `Setting up ${pkgName} ...\n` +
                `[APT SUCCESS] تم تثبيت الحزمة "${pkgName}" بنجاح في بيئة المطورين لترمكس!`,
                'success'
              );
            }
          } else {
            writeOutput(
              'أداة إدارة الحزم المتقدمة APT تدعم:\n' +
              '  apt update          (تحديث قواعد البيانات)\n' +
              '  apt install [name]   (تثبيت حزمة برمجية معينة مثل python, scons, git)\n' +
              '  apt-install [name]   (أمر تثبيت سريع مباشر للمبرمجين)',
              'warning'
            );
          }
        }
        break;

      case 'ping':
        {
          const host = args[1] || 'google.com';
          writeOutput(`PING ${host} (142.250.180.142) 56(84) bytes of data...`, 'system');
          setTimeout(() => { writeOutput(`64 bytes from ${host}: icmp_seq=1 ttl=118 time=14.2 ms`); }, 200);
          setTimeout(() => { writeOutput(`64 bytes from ${host}: icmp_seq=2 ttl=118 time=13.9 ms`); }, 500);
          setTimeout(() => { writeOutput(`64 bytes from ${host}: icmp_seq=3 ttl=118 time=15.1 ms`); }, 800);
          setTimeout(() => { 
            writeOutput(
              `--- ${host} ping statistics ---\n` +
              `3 packets transmitted, 3 received, 0% packet loss, time 2004ms\n` +
              `rtt min/avg/max/mdev = 13.921/14.441/15.122/0.511 ms`,
              'success'
            );
          }, 1000);
        }
        break;

      case 'mkdir':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد اسم المجلد المراد إنشاؤه. مثال: mkdir backups', 'warning');
            break;
          }
          const folderName = args[1];
          const result = createNodeInPath(vfs, currentPath, folderName, 'dir');
          if (result.success) {
            setVfs(result.root);
            writeOutput(`تم إنشاء المجلد بنجاح: ${folderName}`, 'success');
          } else {
            writeOutput(`خطأ: ${result.error}`, 'error');
          }
        }
        break;

      case 'touch':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد اسم ملف لإنشائه. مثال: touch note.txt', 'warning');
            break;
          }
          const fileName = args[1];
          const result = createNodeInPath(vfs, currentPath, fileName, 'file', '');
          if (result.success) {
            setVfs(result.root);
            writeOutput(`تم إنشاء ملف فارغ بنجاح: ${fileName}`, 'success');
          } else {
            writeOutput(`خطأ: ${result.error}`, 'error');
          }
        }
        break;

      case 'rm':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: حدد الملف أو المجلد لحذفه. مثال: rm welcome.txt', 'warning');
            break;
          }
          let nameToDelete = args[1];
          let isRecursive = false;
          
          if (args[1] === '-rf' && args[2]) {
            isRecursive = true;
            nameToDelete = args[2];
          }

          const targetNode = findNodeByPath(vfs, resolvePath(currentPath, nameToDelete));
          if (!targetNode) {
            writeOutput(`خطأ: الملف أو المجلد "${nameToDelete}" غير موجود لليحذف.`, 'error');
            break;
          }

          if (targetNode.type === 'dir' && !isRecursive) {
            writeOutput(`تنبيه: "${nameToDelete}" هو مجلد. امسحه باستخدام رمزه المخصص rm -rf [dir_name]`, 'warning');
            break;
          }

          const result = removeNodeFromPath(vfs, currentPath, nameToDelete);
          if (result.success) {
            setVfs(result.root);
            writeOutput(`تم الحذف بنجاح: ${nameToDelete}`, 'success');
          } else {
            writeOutput(`خطأ في الحذف: ${result.error}`, 'error');
          }
        }
        break;

      case 'cat':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: حدد الملف النصي لقراءة محتواه. مثال: cat note.txt', 'warning');
            break;
          }
          const filename = args[1];
          const resolvedPath = resolvePath(currentPath, filename);
          const node = findNodeByPath(vfs, resolvedPath);
          
          if (node) {
            if (node.type === 'file') {
              writeOutput(node.content || '(الملف فارغ)');
            } else {
              writeOutput(`خطأ: ${filename} هو مجلد وليس ملفاً ليقرأ!`, 'error');
            }
          } else {
            writeOutput(`خطأ: الملف غير موجود: ${filename}`, 'error');
          }
        }
        break;

      case 'tail':
        {
          let numLines = 10;
          let filename = '';
          let errorOccurred = false;

          for (let i = 1; i < args.length; i++) {
            const arg = args[i];
            if (arg === '-n') {
              if (i + 1 < args.length) {
                const parsed = parseInt(args[i + 1], 10);
                if (!isNaN(parsed) && parsed > 0) {
                  numLines = parsed;
                  i++; // skip next arg as it's the number of lines
                } else {
                  writeOutput(`خطأ: قيمة غير صالحة لعدد الأسطر "${args[i + 1]}" بعد خيار -n. يجب أن تكون عدداً موجباً.`, 'error');
                  errorOccurred = true;
                  break;
                }
              } else {
                writeOutput('تنبيه: يجب تحديد عدد الأسطر بعد خيار -n. مثال: tail -n 5 note.txt', 'warning');
                errorOccurred = true;
                break;
              }
            } else if (arg.startsWith('-n')) {
              const parsed = parseInt(arg.substring(2), 10);
              if (!isNaN(parsed) && parsed > 0) {
                numLines = parsed;
              } else {
                writeOutput(`خطأ: قيمة غير صالحة لعدد الأسطر "${arg}" بعد خيار -n. يجب أن تكون عدداً موجباً.`, 'error');
                errorOccurred = true;
                break;
              }
            } else {
              filename = arg;
            }
          }

          if (errorOccurred) {
            break;
          }

          if (!filename) {
            writeOutput('تنبيه: الرجاء تحديد مسار الملف النصي لقراءة نهايته. مثال: tail -n 5 note.txt', 'warning');
            break;
          }

          const resolvedPath = resolvePath(currentPath, filename);
          const node = findNodeByPath(vfs, resolvedPath);
          
          if (node) {
            if (node.type === 'file') {
              const content = node.content || '';
              const lines = content.split('\n');
              const lastLines = lines.slice(-numLines);
              writeOutput(lastLines.join('\n'));
            } else {
              writeOutput(`خطأ: "${filename}" هو مجلد وليس ملفاً ليقرأ!`, 'error');
            }
          } else {
            writeOutput(`خطأ: الملف غير موجود: "${filename}"`, 'error');
          }
        }
        break;

      case 'find':
        {
          let searchPath = currentPath;
          let namePattern: string | undefined = undefined;
          let error = false;

          for (let i = 1; i < args.length; i++) {
            const arg = args[i];
            if (arg === '-name') {
              if (i + 1 < args.length) {
                namePattern = args[i + 1];
                i++;
              } else {
                writeOutput('تنبيه: يجب تحديد نمط البحث بالاسم بعد خيار -name. مثال: find . -name "*.txt"', 'warning');
                error = true;
                break;
              }
            } else if (arg.startsWith('-')) {
              writeOutput(`خطأ: الخيار غير معروف: "${arg}". الخيار المدعوم هو -name فقط.`, 'error');
              error = true;
              break;
            } else {
              searchPath = resolvePath(currentPath, arg);
            }
          }

          if (error) {
            break;
          }

          const startNode = findNodeByPath(vfs, searchPath);
          if (!startNode) {
            writeOutput(`خطأ: المسار غير موجود: "${searchPath}"`, 'error');
            break;
          }

          const matchResults: string[] = [];
          const traverse = (node: FSNode, path: string) => {
            const nameLower = node.name.toLowerCase();
            let isMatch = true;

            if (namePattern) {
              const cleanPattern = namePattern.replace(/['"*]/g, '').toLowerCase();
              isMatch = nameLower.includes(cleanPattern);
            }

            if (path !== '/' && isMatch) {
              matchResults.push(path);
            }

            if (node.type === 'dir' && node.children) {
              const sortedKeys = Object.keys(node.children).sort();
              sortedKeys.forEach(key => {
                const childNode = node.children![key];
                const nextPath = path === '/' ? `/${key}` : `${path}/${key}`;
                traverse(childNode, nextPath);
              });
            }
          };

          traverse(startNode, searchPath);

          if (matchResults.length === 0) {
            writeOutput('لم يتم العثور على أي ملفات أو مجلدات مطابقة.', 'warning');
          } else {
            writeOutput(matchResults.join('\n'));
          }
        }
        break;

      case 'echo':
        {
          const fullCommand = args.slice(1).join(' ');
          
          // Check for append redirect sign ">>"
          const appendIdx = fullCommand.indexOf('>>');
          
          if (appendIdx !== -1) {
            const textToAppend = fullCommand.substring(0, appendIdx).replace(/"/g, '').trim();
            const filePathPart = fullCommand.substring(appendIdx + 2).trim();
            const resolvedPath = resolvePath(currentPath, filePathPart);
            
            const existingNode = findNodeByPath(vfs, resolvedPath);
            let updatedContent = textToAppend;
            if (existingNode && existingNode.type === 'file') {
              updatedContent = (existingNode.content || '') + (existingNode.content ? '\n' : '') + textToAppend;
            }
            
            const result = updateFileContent(vfs, resolvedPath, updatedContent);
            if (result.success) {
              setVfs(result.root);
              writeOutput(`تمت إضافة النص بنجاح إلى نهاية ملف "${filePathPart}"`, 'success');
            } else {
              writeOutput(`خطأ أثناء إلحاق النص للملف: ${result.error}`, 'error');
            }
          } else {
            // Check for overwrite redirect sign ">"
            const redirectIdx = fullCommand.indexOf('>');
            if (redirectIdx === -1) {
              writeOutput(fullCommand);
            } else {
              const textToSave = fullCommand.substring(0, redirectIdx).replace(/"/g, '').trim();
              const filePathPart = fullCommand.substring(redirectIdx + 1).trim();
              const resolvedPath = resolvePath(currentPath, filePathPart);
              
              const result = updateFileContent(vfs, resolvedPath, textToSave);
              if (result.success) {
                setVfs(result.root);
                writeOutput(`تمت الكتابة بنجاح إلى ملف "${filePathPart}"`, 'success');
              } else {
                writeOutput(`خطأ أثناء حفظ الملف: ${result.error}`, 'error');
              }
            }
          }
        }
        break;

      case 'grep':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد نمط البحث والملف. مثال: grep Pixel /system/build.prop', 'warning');
            break;
          }
          
          let patternIdx = 1;
          let caseInsensitive = false;
          let showLineNumbers = false;
          
          while (patternIdx < args.length && args[patternIdx].startsWith('-')) {
            const flag = args[patternIdx];
            if (flag.includes('i')) caseInsensitive = true;
            if (flag.includes('n')) showLineNumbers = true;
            patternIdx++;
          }
          
          if (patternIdx >= args.length) {
            writeOutput('تنبيه: يجب إدخال نمط للبحث. مثال: grep -i [pattern] [filename]', 'warning');
            break;
          }
          
          const pattern = args[patternIdx].replace(/"/g, '');
          const filename = args[patternIdx + 1];
          
          if (!filename) {
            writeOutput('تنبيه: الرجاء تحديد ملف للبحث فيه. مثال: grep -i "pixel" /system/build.prop', 'warning');
            break;
          }
          
          const resolvedPath = resolvePath(currentPath, filename);
          const fileNode = findNodeByPath(vfs, resolvedPath);
          
          if (!fileNode) {
            writeOutput(`خطأ: الملف غير موجود: ${filename}`, 'error');
            break;
          }
          
          if (fileNode.type !== 'file') {
            writeOutput(`خطأ: "${filename}" هو مجلد وليس ملفاً نقدر نفتشه!`, 'error');
            break;
          }
          
          const fileLines = (fileNode.content || '').split('\n');
          const foundLines: string[] = [];
          
          fileLines.forEach((line, index) => {
            let matches = false;
            if (caseInsensitive) {
              matches = line.toLowerCase().includes(pattern.toLowerCase());
            } else {
              matches = line.includes(pattern);
            }
            
            if (matches) {
              const lineText = showLineNumbers ? `${index + 1}:${line}` : line;
              foundLines.push(lineText);
            }
          });
          
          if (foundLines.length === 0) {
            writeOutput(`تنبيه: لم يتم العثور على أي نتائج مطابقة لـ "${pattern}"`, 'warning');
          } else {
            writeOutput(foundLines.join('\n'), 'success');
          }
        }
        break;

      case 'nano':
      case 'edit':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء إدخال اسم ملف لفتحه في محرّر غنو نانو. مثال: edit welcome_note.txt', 'warning');
            break;
          }
          const filename = args[1];
          const resolvedPath = resolvePath(currentPath, filename);
          const fileNode = findNodeByPath(vfs, resolvedPath);
          
          if (fileNode && fileNode.type === 'dir') {
            writeOutput('خطأ: لا يمكنك تحرير مجلد بمحرر النصوص.', 'error');
            break;
          }

          setEditingFile({
            filename,
            path: resolvedPath,
            content: fileNode ? (fileNode.content || '') : ''
          });
          writeOutput(`جاري تشغيل محرر nano وفتح الملف: ${filename}...`, 'system');
        }
        break;

      case 'su':
        setIsRoot(true);
        writeOutput(
          '=======================================================\n' +
          '[SU GRANTED] تم فك كود الحماية ومنح التطبيق صلاحية الروت (SuperUser)!\n' +
          'لقد تحولت الآن للمستخدم الخارق. انتبه أثناء التعديل على ملفات النظام.\n' +
          '=======================================================',
          'warning'
        );
        break;

      case 'login:root':
        setIsRoot(true);
        writeOutput(
          '=======================================================\n' +
          '[LOGIN:ROOT SUCCESS] تم فك تشفير الجلسة وتسجيل الدخول كـ (root)!\n' +
          'معرّفات الهوية تحولت الآن للمستخدم الخارق بنجاح.\n' +
          '=======================================================',
          'success'
        );
        break;

      case 'id':
        if (isRoot) {
          writeOutput(
            'uid=0(root) gid=0(root) groups=0(root) context=u:r:su:s0\n' +
            '-------------------------------------------------------\n' +
            'المستخدم الحالي: root (المستودع الخارق - الروت بنجاح)',
            'success'
          );
        } else {
          writeOutput(
            'uid=10105(shell) gid=10105(shell) groups=10105(shell),3003(inet) context=u:r:shell:s0\n' +
            '-------------------------------------------------------\n' +
            'المستخدم الحالي: shell (مستخدم افتراضي عادٍ دون صلاحيات كاملة)',
            'system'
          );
        }
        break;

      case 'python':
      case 'python3':
        {
          if (!isPythonInstalled) {
            writeOutput(
              'sh: python: command not found\n' +
              'لم يتم تحميل نظام تشغيل البايثون في بيئة Termux الافتراضية بعد.\n\n' +
              'لتثبيتها، استخدم مدير الحزم التالي:\n' +
              '  pkg install python\n' +
              '  أو اضغط على زر التثبيت من علامة التبويب "الخادم المحلي (Localhost) / Python".',
              'error'
            );
            break;
          }

          if (args.length < 2) {
            setPythonReplActive(true);
            setPythonEnv({});
            writeOutput(
              'Python 3.10.6 (main, May 29 2026, 11:10:28) \n' +
              '[Clang 14.0.7 (https://android.googlesource.com/toolchain/llvm)] on linux\n' +
              'Type "help", "copyright", "credits" or "license" for more information.\n' +
              '>>> (اكتب exit() أو quit() للعودة لسطر الأوامر العادي)',
              'success'
            );
            break;
          }

          const arg1 = args[1];
          if (arg1 === '-V' || arg1 === '--version') {
            writeOutput('Python 3.10.6', 'success');
          } else if (arg1 === '-h' || arg1 === '--help') {
            writeOutput(
              'usage: python [option] ... [-c cmd | -m mod | file | -] [arg] ...\n' +
              'Options and arguments:\n' +
              '  -V, --version : print the Python version number and exit\n' +
              '  -h, --help    : print this help message and exit\n' +
              '  -m mod        : run library module as a script (e.g. -m http.server)\n' +
              '  file          : program read from script file',
              'system'
            );
          } else if (arg1 === '-m') {
            const moduleName = args[2];
            if (moduleName === 'http.server') {
              let portNum = 8000;
              if (args[3]) {
                const parsedPort = parseInt(args[3], 10);
                if (!isNaN(parsedPort) && parsedPort > 0) {
                  portNum = parsedPort;
                }
              }

              const portIsTaken = runningServers.some(srv => srv.port === portNum);
              if (portIsTaken) {
                writeOutput(`خطأ: المنفذ ${portNum} قيد الاستخدام بالفعل!`, 'error');
              } else {
                const newServer = { port: portNum, path: currentPath, host: 'localhost' };
                setRunningServers((prev) => [...prev, newServer]);
                writeOutput(
                  `Serving HTTP on 0.0.0.0 port ${portNum} (http://127.0.0.1:${portNum}/) ...\n` +
                  `[LOCAL SERVER ACTIVE] تم تشغيل خادم محلي بنجاح على المنفذ ${portNum}!\n` +
                  `تصفح المجلد الحالي: "${currentPath}" من خلال علامة التبويب "الخادم المحلي (Localhost) / Python".`,
                  'success'
                );
              }
            } else {
              writeOutput(`خطأ: الوحدة "${moduleName}" غير مدعومة للمحاكاة. جرب python -m http.server`, 'error');
            }
          } else {
            const resolvedPath = resolvePath(currentPath, arg1);
            const node = findNodeByPath(vfs, resolvedPath);
            if (node) {
              if (node.type === 'file') {
                const content = node.content || '';
                const lines = content.split('\n');
                let outputLines: string[] = [];
                let localVars: Record<string, any> = {};

                for (let line of lines) {
                  line = line.trim();
                  if (!line || line.startsWith('#')) continue;

                  if (line.startsWith('print(')) {
                    const printMatch = line.match(/^print\((['"])(.*?)\1\)$/);
                    if (printMatch) {
                      outputLines.push(printMatch[2]);
                    } else {
                      const printVarMatch = line.match(/^print\((.*?)\)$/);
                      if (printVarMatch) {
                        const expr = printVarMatch[1].trim();
                        if (localVars[expr] !== undefined) {
                          outputLines.push(String(localVars[expr]));
                        } else {
                          try {
                            const evalVal = Function(`return (${expr})`)();
                            outputLines.push(String(evalVal));
                          } catch (e) {
                            outputLines.push(`NameError: name '${expr}' is not defined`);
                          }
                        }
                      }
                    }
                  } else if (line.includes('=')) {
                    const eqParts = line.split('=');
                    if (eqParts.length === 2) {
                      const vName = eqParts[0].trim();
                      const vVal = eqParts[1].trim();
                      if (/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(vName)) {
                        try {
                          const val = Function(`return (${vVal})`)();
                          localVars[vName] = val;
                        } catch (e) {
                          localVars[vName] = vVal.replace(/['"]/g, '');
                        }
                      }
                    }
                  }
                }

                writeOutput(
                  `[Python Runner: ${arg1}]\n` +
                  `-------------------------------------------------------\n` +
                  (outputLines.length > 0 ? outputLines.join('\n') : '(نهاية تشغيل الملف، لم يتم طباعة أي نتائج)'),
                  'success'
                );
              } else {
                writeOutput(`خطأ: "${arg1}" هو مجلد وليس ملف بايثون نصي!`, 'error');
              }
            } else {
              writeOutput(`python: can't open file '${arg1}': [Errno 2] No such file or directory`, 'error');
            }
          }
        }
        break;

      case 'stop-server':
      case 'kill-server':
        {
          if (args.length < 2) {
            writeOutput('تنبيه: الرجاء تحديد منفذ الخادم المراد إيقافه. مثال: stop-server 8000', 'warning');
            break;
          }
          const portToStop = parseInt(args[1], 10);
          if (isNaN(portToStop)) {
            writeOutput('خطأ: منفذ غير صالح.', 'error');
            break;
          }
          const hasServer = runningServers.some(srv => srv.port === portToStop);
          setRunningServers(prev => prev.filter(srv => srv.port !== portToStop));
          if (hasServer) {
            writeOutput(`[SERVER STOPPED] تم إغلاق الخادم المحلي على المنفذ ${portToStop} بنجاح.`, 'success');
          } else {
            writeOutput(`تنبيه: لم يتم العثور على خادم محلي نشط يعمل على المنفذ ${portToStop}.`, 'warning');
          }
        }
        break;

      case 'exit':
        if (isRoot) {
          setIsRoot(false);
          writeOutput('تم الخروج من سطر الروت، العودة لوضعية $ العادية من الأندرويد.', 'system');
        } else {
          writeOutput('أنت تعمل بالفعل في أدنى طبقة مستخدم، لا يمكن التبسيط أكثر.', 'warning');
        }
        break;

      case 'getprop':
        {
          const resolvedPath = '/system/build.prop';
          const node = findNodeByPath(vfs, resolvedPath);
          if (node && node.type === 'file' && node.content) {
            if (args.length === 1) {
              writeOutput(node.content);
            } else {
              const key = args[1];
              const lines = node.content.split('\n');
              const foundLine = lines.find(l => l.startsWith(`${key}=`));
              if (foundLine) {
                writeOutput(foundLine.split('=')[1], 'success');
              } else {
                writeOutput(`[getprop] خطأ: تعذر العثور على الخاصية "${key}" في النظام.`, 'error');
              }
            }
          } else {
            writeOutput('خطأ: تعذر تحميل ملف build.prop من النظام.', 'error');
          }
        }
        break;

      case 'dumpsys':
        {
          if (args.length > 1 && args[1] === 'battery') {
            writeOutput(
              `Current Battery Service State:\n` +
              `  AC powered: false\n` +
              `  USB powered: ${isConnected ? 'true' : 'false'}\n` +
              `  Wireless powered: false\n` +
              `  Max charging current: 1500000 microAmps\n` +
              `  status: ${isConnected ? '2 (Charging)' : '3 (Discharging)'}\n` +
              `  health: 2 (Fantastic - Good)\n` +
              `  present: true\n` +
              `  level: ${batteryLevel}%\n` +
              `  scale: 100\n` +
              `  voltage: 3822 mV\n` +
              `  temperature: 294 tenths of C (29.4°C)\n` +
              `  technology: Li-poly`,
              'success'
            );
          } else {
            writeOutput('الرجاء استخدام الأبعاد الأعمق، مثل dumpsys battery لقراءة صحة البطارية وتفاصيل المنفذ.', 'warning');
          }
        }
        break;

      case 'wm':
        {
          if (args.length > 1 && args[1] === 'size') {
            if (args.length === 2) {
              writeOutput('Physical display size: 1344x2992 (forced is 1080x1920)');
            } else if (args[2] === 'reset') {
              writeOutput('Display resolution reset to native (1344x2992) for high res screen.');
            } else {
              writeOutput(`Overriding display density config... physical frame screen size set forced to: ${args[2]}`);
            }
          } else if (args.length > 1 && args[1] === 'density') {
            if (args.length === 2) {
              writeOutput('Physical density config: 480 dpi');
            } else {
              writeOutput(`Success scaling display pixel layout forced density: ${args[2]}`);
            }
          } else {
            writeOutput('الرجاء كتابة تفاصيل تعديل الشاشة مثل: wm size أو wm density 440', 'warning');
          }
        }
        break;

      case 'pm':
        {
          if (args.length > 1 && args[1] === 'list' && args[2] === 'packages') {
            let ptype = 'All';
            if (args[3] === '-3') ptype = 'User (3rd Party)';
            if (args[3] === '-s') ptype = 'Core System';
            
            const packagesToShow = ptype === 'Core System' 
              ? installedPackages.filter(p => p.startsWith('com.android') || p.startsWith('com.google'))
              : ptype === 'User (3rd Party)'
                ? installedPackages.filter(p => !p.startsWith('com.android') && !p.startsWith('com.google'))
                : installedPackages;

            const listStr = packagesToShow.map(p => `  package:${p}`).join('\n');
            writeOutput(
              `Filtering Android packages [Type: ${ptype}]:\n${listStr}`,
              'success'
            );
          } else if (args.length > 1 && args[1] === 'install') {
            const apkFile = args[2];
            if (!apkFile) {
              writeOutput('تنبيه: يرجى تحديد اسم حزمة الـ APK لتثبيتها. مثال: pm install myapp.apk', 'warning');
            } else {
              writeOutput(`[PM] جاري التحقق من ملف التثبيت: ${apkFile}...`, 'system');
              let pName = 'com.example.' + apkFile.toLowerCase().replace(/\.apk$/, '').replace(/[^a-z0-9]/g, '');
              if (!pName.endsWith('.app') && !pName.includes('.app.')) pName += '.app';
              
              setTimeout(() => { writeOutput(`[PM] جاري فحص بنية وبصمة الـ APK (Signature: Valid)...`); }, 200);
              setTimeout(() => { writeOutput(`[PM] تحسين أداء تشغيل البرنامج dex2oat...`); }, 500);
              setTimeout(() => {
                setInstalledPackages(prev => {
                  if (!prev.includes(pName)) {
                    return [...prev, pName];
                  }
                  return prev;
                });
                writeOutput(`[PM SUCCESS] تم تثبيت الحزمة "${pName}" بنجاح على نظام الأندرويد!`, 'success');
              }, 900);
            }
          } else if (args.length > 1 && args[1] === 'clear') {
            if (args[2]) {
              writeOutput(`Success: Cleared user storage data and cache for package: ${args[2]}`, 'success');
            } else {
              writeOutput('خطأ: حدد حزمة البرنامج للمسح. مثال: pm clear com.whatsapp', 'error');
            }
          } else {
            writeOutput(
              'أمر مدير الحزم pm للأندرويد يدعم:\n' +
              '- pm list packages (عرض التطبيقات المثبتة)\n' +
              '- pm list packages -3 (عرض تطبيقات المستخدم فقط)\n' +
              '- pm list packages -s (عرض تطبيقات النظام فقط)\n' +
              '- pm install [apk_file] (تثبيت حزمة APK جديدة على الهاتف)\n' +
              '- pm clear [package_name] (مسح وتصفير بيانات التطبيق)',
              'warning'
            );
          }
        }
        break;

      case 'sh':
      case 'shell':
        writeOutput(
          '=======================================================\n' +
          '[BASH] مرحباً بك في سطر أوامر المحاكاة للأندرويد (/system/bin/sh)\n' +
          'الصدفة الفعالة: sh/bash (v5.2.15-release)\n' +
          'متغيرات البيئة المعرفة (Environment Variables):\n' +
          '  PATH=/sbin:/system/sbin:/system/bin:/system/xbin:/data/data/com.termux/files/usr/bin\n' +
          '  HOME=/data/data/com.termux/files/home\n' +
          '  TMPDIR=/data/data/com.termux/files/usr/tmp\n' +
          '  TERM=xterm-256color\n' +
          '  USER=shell\n' +
          'المنفذ مهيأ لاهتزازات اللمس والاستجابة المباشرة. اكتب "help" للأدوات.\n' +
          '=======================================================',
          'success'
        );
        break;

      case 'install-apk':
        {
          const apkFile = args[1];
          if (!apkFile) {
            writeOutput('تنبيه: يرجى تحديد اسم ملف الـ APK لتثبيته. مثال: install-apk myapp.apk', 'warning');
          } else {
            writeOutput(`[APK-INSTALL] جاري بدء عملية تثبيت ملف APK: ${apkFile}...`, 'system');
            let pName = 'com.example.' + apkFile.toLowerCase().replace(/\.apk$/, '').replace(/[^a-z0-9]/g, '');
            if (!pName.endsWith('.app')) pName += '.app';
            
            setTimeout(() => { writeOutput(`[PM] جاري فحص الحزمة والتحقق من التوقيع...`); }, 200);
            setTimeout(() => {
              setInstalledPackages(prev => {
                if (!prev.includes(pName)) {
                  return [...prev, pName];
                }
                return prev;
              });
              writeOutput(`[PM] SUCCESS: حزمة "${pName}" جاهزة للعمل ومثبتة بنجاح!`, 'success');
            }, 800);
          }
        }
        break;

      case 'apkbuild':
      case 'build-apk':
      case 'apktool':
      case 'gradlew':
        {
          const isCompile = cmd === 'apkbuild' || cmd === 'build-apk' || (cmd === 'apktool' && (args[1] === 'b' || args[1] === 'build')) || (cmd === 'gradlew' && args[1] === 'assembleDebug');
          
          if (isCompile) {
            const targetFolder = args[cmd === 'apktool' || cmd === 'gradlew' ? 2 : 1] || 'current directory';
            writeOutput(`[APKBUILD] جاري استدعاء محرك بناء ملفات الأندرويد (AAPT2) لتجميع المجلد: ${targetFolder}...`, 'system');
            
            setTimeout(() => { writeOutput(`[APKBUILD] جاري استيراد وتحليل ملف AndroidManifest.xml...`); }, 150);
            setTimeout(() => { writeOutput(`[APKBUILD] جاري دمج وتجميع موارد التطبيق (Resources Compiling)...`); }, 400);
            setTimeout(() => { writeOutput(`[APKBUILD] جاري صنع ملفات classes.dex (R8/D8 Optimization)...`); }, 700);
            setTimeout(() => { writeOutput(`[APKBUILD] جاري إنتاج الأرشيف النهائي ومحاذاة البيانات (zipalign)...`); }, 1050);
            setTimeout(() => { writeOutput(`[APKBUILD] جاري توقيع الحزمة بشهادة اختبار المطورين العشوائية (apksigner)...`); }, 1400);
            setTimeout(() => {
              const outputApkName = 'app-debug.apk';
              const result = createNodeInPath(vfs, currentPath, outputApkName, 'file', 'APK BINARY STREAM - SIMULATED ANDROID APPLICATION RESOURCE FILE');
              if (result.success) {
                setVfs(result.root);
                writeOutput(`[APKBUILD SUCCESS] تم بناء ملف الـ APK بنجاح وحفظه كـ "${outputApkName}" في المسار الحالي (${currentPath})!`, 'success');
              } else {
                writeOutput(`[APKBUILD SUCCESS] تم بناء حزمة الأندرويد بنجاح! ولكن تعذر تدوينها في المجلد بسبب: ${result.error}`, 'warning');
              }
            }, 1750);
          } else if (cmd === 'apktool') {
            writeOutput(
              'أداة تفكيك وتجميع حزم الأندرويد Apktool تدعم:\n' +
              '  apktool d [app.apk]   (تفكيك ملف APK لقراءة مصادره ومخططاته)\n' +
              '  apktool b [folder]    (تجميع وبناء مجلد مصادر إلى ملف APK جديد)',
              'warning'
            );
          } else {
            writeOutput('أمر تجميع مشاريع جردل يدعم:\n  gradlew assembleDebug لبناء ملف APK تجريبي.', 'warning');
          }
        }
        break;

      case 'logcat':
        setIsLogcatActive(true);
        writeOutput(
          '=======================================================\n' +
          '[RUNNING LOGCAT] جاري بدء التدفق المباشر لسجلات نواة الأندرويد...\n' +
          'لمراقبة الأحداث بشكل مستمر. لإيقاف Logcat اضغط على زر "إيقاف البث الحي" أدناه أو اكتب أي أمر.\n' +
          '=======================================================',
          'warning'
        );
        break;

      case 'ps':
      case 'top':
        writeOutput(
          `PID   USER     PR  NI   VIRT    RES    SHR S  %CPU %MEM     TIME+  COMMAND\n` +
          ` 1502 system   20   0  2.8G  148M    94M S   2.4  2.1   0:45.33  system_server\n` +
          ` 2143 u0_a243  20   0  1.4G   52M    38M R   1.2  0.8   0:08.56  com.termux\n` +
          `  812 system   20   0  812M   44M    24M S   0.5  0.4   0:12.11  surfaceflinger\n` +
          `  433 root     20   0    0M    0M     0M S   0.1  0.0   0:00.64  ksoftirqd/0\n` +
          ` 2101 system   21   1  1.6G   68M    42M S   0.1  1.1   0:04.90  com.android.systemui`,
          'success'
        );
        break;

      case 'uptime':
        writeOutput('17:31:44 up 4:32, 1 user, load average: 0.12, 0.08, 0.04', 'success');
        break;

      case 'df':
        writeOutput(
          `Filesystem           Size     Used     Free   Blksize\n` +
          `/dev/block/dm-0      9.4G     4.2G     5.2G   4096\n` +
          `/system              2.4G     2.1G     0.3G   4096\n` +
          `/data               54.2G    32.1G    22.1G   4096\n` +
          `/storage/emulated   256.0G   124.2G   131.8G   4096`,
          'success'
        );
        break;

      case 'free':
        writeOutput(
          `             total         used         free       shared      buffers\n` +
          `Mem:      12140432      7321458      4818974            0       142322\n` +
          `-/+ buffers/cache:      7179136      4961296\n` +
          `Swap:      6291456            0      6291456`,
          'success'
        );
        break;

      case 'reboot':
        triggerReboot();
        break;

      case 'adb':
        {
          if (args[1] === 'install') {
            const apkFile = args[2];
            if (!apkFile) {
              writeOutput('تنبيه: حدد ملف الـ APK لتثبيته. مثال: adb install app.apk', 'warning');
            } else {
              writeOutput(`[ADB] جاري إرسال حزمة الـ APK "${apkFile}" عبر منفذ USB...`, 'system');
              let pName = 'com.example.' + apkFile.toLowerCase().replace(/\.apk$/, '').replace(/[^a-z0-9]/g, '');
              if (!pName.endsWith('.app')) pName += '.app';
              
              setTimeout(() => { writeOutput(`[ADB] جاري تثبيت الحزمة على جهاز Pixel 8 Pro...`); }, 300);
              setTimeout(() => {
                setInstalledPackages(prev => {
                  if (!prev.includes(pName)) {
                    return [...prev, pName];
                  }
                  return prev;
                });
                writeOutput(`[ADB SUCCESS] Successfully installed "${apkFile}" -> Package: "${pName}"`, 'success');
              }, 1000);
            }
          } else {
            writeOutput(
              'أمر الـ ADB يستدعى عادة من الكمبيوتر الخارجي للاتصال بالهاتف الحالي الموصول عبر الـ USB.\n' +
              '  قم بتفعيل خيار "USB Debugging" من خيارات المطور بالهاتف.\n' +
              '  قم بتشغيل منفذ الأندرويد بـ adb connect [الهاتف_IP] لتتصل بالجهاز لاسلكياً!\n\n' +
              'الأوامر الجانبية في القاموس توضح كيفية الربط الكامل للمشاريع.',
              'warning'
            );
          }
        }
        break;

      case 'pkg':
        if (args.length > 1 && args[1] === 'update') {
          writeOutput(
            'Updating Termux packages database...\n' +
            '  Hit https://dl.bintray.com/termux/termux-packages-24 stable InRelease\n' +
            '  Reading package lists... Done.\n' +
            '  All packages database mirrors up-to-date and ready.',
            'success'
          );
        } else if (args.length > 1 && args[1] === 'install') {
          if (args[2]) {
            if (args[2].toLowerCase() === 'python' || args[2].toLowerCase() === 'python3') {
              setIsPythonInstalled(true);
            }
            writeOutput(`Downloading package ${args[2]}...\nUnpacking data...\nSet permissions 755...\nPackage ${args[2]} installed and ready in termux binary path!`, 'success');
          } else {
            writeOutput('خطأ: الرجاء تحديد الحزمة التي تود تثبيتها في ترمكس. مثل pkg install python', 'error');
          }
        } else {
          writeOutput('أكواد مدير الحزم pkg لترمكس تدعم: pkg update و pkg install [اسم_الأداة]', 'warning');
        }
        break;

      case 'termux-battery-status':
        writeOutput(
          `{\n` +
          `  "health": "GOOD",\n` +
          `  "percentage": ${batteryLevel},\n` +
          `  "plugged": "USB_PLUGGED",\n` +
          `  "status": "CHARGING",\n` +
          `  "temperature": 29.4\n` +
          `}`,
          'success'
        );
        break;

      case 'termux-vibrate':
        writeOutput('[VIBRATING DEVICE...] تمت محاكاة للاهتزاز اللمسي بالهاتف بنجاح في بيئة الويب.', 'success');
        break;

      default:
        writeOutput(`[sh] خطأ: الأمر "${cmd}" غير مدعوم أو غير مكتوب بشكل صحيح. اكتب help لعرض الكلمات المفتاحية لمساعد الأندرويد.`, 'error');
        break;
    }

        return !commandFailed;
      };

      const success = runSingleCommand(item.command);
      lastSuccess = success;
    }

    // Commit final values as a batch to React state
    setHistory(historyLocal);
    setVfs(vfsLocal);
    setCurrentPath(currentPathLocal);
    setIsRoot(isRootLocal);
    setAliases(aliasesLocal);
  };

  // Run command from external manual injector
  const handleInjectCommand = (cmd: string, runImmediately: boolean) => {
    if (runImmediately) {
      setInputVal('');
      handleExecuteCommand(cmd);
    } else {
      setInputVal(cmd);
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  };

  // Autocomplete file names or commands
  const handleAutocomplete = () => {
    const trimmed = inputVal.trim();
    if (!trimmed) return;

    const parts = trimmed.split(' ');
    // Only autocompleting files/dirs if inside ls, cd, cat, edit, nano, rm
    if (parts.length >= 2) {
      const activeCmd = parts[0].toLowerCase();
      const prefix = parts.slice(1).join(' ');
      
      if (['cd', 'cat', 'rm', 'edit', 'nano'].includes(activeCmd)) {
        const targetNode = findNodeByPath(vfs, currentPath);
        if (targetNode && targetNode.type === 'dir' && targetNode.children) {
          const files = Object.keys(targetNode.children);
          const matches = files.filter(f => f.startsWith(prefix));
          if (matches.length === 1) {
            setInputVal(`${parts[0]} ${matches[0]}`);
          } else if (matches.length > 1) {
            setHistory(prev => [
              ...prev,
              {
                id: 'auto-' + Math.random(),
                text: matches.map(m => `📄 ${m}`).join('   '),
                type: 'system',
                timestamp: getPreciseTimestamp()
              }
            ]);
          }
        }
      }
    } else {
      // Autocomplete basic terminal commands using commandHints
      const popularCmds = Object.keys(commandHints);
      const matches = popularCmds.filter(c => c.startsWith(trimmed.toLowerCase()));
      if (matches.length === 1) {
        setInputVal(matches[0]);
      }
    }
  };

  // Handle Keyboard events inside terminal
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleExecuteCommand(inputVal);
      setInputVal('');
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (cmdHistory.length > 0) {
        const nextIdx = historyIdx === -1 ? cmdHistory.length - 1 : Math.max(0, historyIdx - 1);
        setHistoryIdx(nextIdx);
        setInputVal(cmdHistory[nextIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (cmdHistory.length > 0 && historyIdx !== -1) {
        const nextIdx = historyIdx + 1;
        if (nextIdx >= cmdHistory.length) {
          setHistoryIdx(-1);
          setInputVal('');
        } else {
          setHistoryIdx(nextIdx);
          setInputVal(cmdHistory[nextIdx]);
        }
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      handleAutocomplete();
    }
  };

  // Virtual file save callback
  const handleSaveFileContent = (newContent: string) => {
    if (editingFile) {
      const result = updateFileContent(vfs, editingFile.path, newContent);
      if (result.success) {
        setVfs(result.root);
        setHistory(prev => [
          ...prev,
          {
            id: 'nano-save-' + Math.random(),
            text: `[nano] تم حفظ تعديلات الملف بنجاح في المسار: ${editingFile.path}`,
            type: 'success',
            timestamp: getPreciseTimestamp()
          }
        ]);
        setEditingFile(null);
      } else {
        alert('حدث خطأ في الحفظ!');
      }
    }
  };

  return (
    <div id="app-viewport" className="min-h-screen bg-[#070707] text-neutral-200 font-sans flex flex-col antialiased">
      {/* Dynamic Status Bar - Luxury Dashboard Header */}
      <header id="header-bar" className="bg-neutral-950 border-b border-neutral-900 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 select-none">
        
        {/* Left Side Indicators */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded font-mono text-neutral-400">
            <Smartphone size={13} className="text-neutral-500" />
            <span className="hidden sm:inline">الجهاز:</span>
            <span className="font-bold text-neutral-300">Pixel 8 Pro</span>
          </div>

          <div className="flex items-center gap-1.5 px-2 py-1 bg-neutral-900 border border-neutral-800 rounded font-mono text-neutral-400">
            <Cpu size={13} className="text-neutral-500" />
            <span className="hidden sm:inline">نظام:</span>
            <span className="font-bold text-neutral-300">Android 14</span>
          </div>
        </div>

        {/* Center Title - Elegant Branding */}
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-neutral-600 animate-pulse" />
          <h1 className="text-sm font-black text-neutral-100 tracking-tight">
            برنامج الطرفية للأندرويد ودليل الـ ADB التفاعلي
          </h1>
          <span className="text-xs text-neutral-500 bg-neutral-900 border border-neutral-800 px-2 py-0.5 rounded font-mono font-semibold hidden md:inline">
            grey_terminal_r4
          </span>
        </div>

        {/* Right Status Indicators (Battery, WiFi, Root, Upload, Reboot Button) */}
        <div className="flex items-center gap-3">
          {/* Su Root Active state */}
          <div 
            onClick={() => setIsRoot(!isRoot)} 
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border transition cursor-pointer font-bold ${
              isRoot 
                ? 'bg-neutral-800 text-white border-white/40' 
                : 'bg-neutral-900 text-neutral-500 border-neutral-850'
            }`}
            title="تفعيل/تعطيل صلاحيات الروت بنقرة"
          >
            <Shield size={13} className={isRoot ? 'text-white' : 'text-neutral-600'} />
            <span className="font-mono text-[10px]">{isRoot ? 'ROOT: ON' : 'ROOT: OFF'}</span>
          </div>

          {/* File Upload to Root (/) */}
          <label className="flex items-center gap-1.5 px-2.5 py-1 bg-neutral-900 hover:bg-neutral-800 hover:text-white border border-neutral-800 rounded text-neutral-400 text-[10px] sm:text-xs transition cursor-pointer font-mono" title="رفع ملف إلى مجلد الجذر (/)">
            <Upload size={13} className="text-neutral-500 hover:text-neutral-350" />
            <span className="font-bold">رفع ملف للجذر (/)</span>
            <input 
              type="file" 
              className="hidden" 
              onChange={handleFileUpload}
            />
          </label>

          {/* Device online signal */}
          <div className="flex items-center gap-1.5 text-neutral-400 text-xs font-mono">
            <Wifi size={14} className="text-neutral-400" />
            <span className="hidden sm:inline">LAN</span>
          </div>

          {/* Battery Status */}
          <div className="flex items-center gap-1 text-xs font-mono">
            <Battery size={15} className="text-neutral-400" />
            <span className="text-neutral-300">{batteryLevel}%</span>
          </div>

          {/* Physical reboot simulator */}
          <button 
            type="button" 
            onClick={triggerReboot}
            className="p-1.5 text-neutral-400 hover:text-white bg-neutral-900 hover:bg-neutral-850 border border-neutral-800 rounded transition cursor-pointer"
            title="إعادة تشغيل المحاكي (Reboot)"
          >
            <RefreshCw size={13} />
          </button>
        </div>
      </header>

      {/* Main Body Grid */}
      <main id="main-grid" className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 min-y-0 text-right overflow-hidden">
        
        {/* LEFT COLUMN: Terminal Shell Simulation (Lg: 7/12) */}
        <section id="terminal-section" className="lg:col-span-7 flex flex-col h-full bg-[#0a0a0b] border border-neutral-900 rounded-xl overflow-hidden shadow-2xl relative">
          
          {/* Terminal Top Window Title Chrome */}
          <div className="bg-neutral-950 border-b border-neutral-900/80 px-4 py-2 flex items-center justify-between select-none">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-neutral-800" />
              <span className="w-2.5 h-2.5 rounded-full bg-neutral-700" />
              <span className="w-2.5 h-2.5 rounded-full bg-neutral-600" />
            </div>
            
            <div className="flex items-center gap-2 font-mono text-xs text-neutral-400 font-bold" dir="ltr">
              <TerminalIcon size={14} className="text-neutral-500" />
              <span>termux_session_0_bin_sh</span>
            </div>

            <div className="flex items-center gap-2.5 text-xs text-neutral-400">
              <span className="font-mono bg-neutral-900 border border-neutral-800/80 px-2.5 py-0.5 rounded text-neutral-300">
                {currentPath}
              </span>
              <span className="hidden sm:inline font-sans font-medium">الموقع الحالي:</span>
            </div>
          </div>

          {/* Embedded Reboot Screen logic */}
          {rebooting ? (
            <div id="reboot-screen" className="flex-1 bg-black p-6 flex flex-col justify-center items-center select-none animate-pulse font-mono text-left" dir="ltr">
              <div className="max-w-md w-full text-neutral-500 text-xs space-y-1 overflow-hidden max-h-48 mb-6 border-l border-neutral-850 pl-3">
                {rebootLogs.map((log, i) => (
                  <div key={i} className="text-[11px] leading-tight">
                    {log}
                  </div>
                ))}
              </div>

              {/* Progress loader */}
              <div className="w-48 bg-neutral-900 h-1.5 rounded-full overflow-hidden border border-neutral-800">
                <div 
                  className="bg-neutral-400 h-full rounded-full transition-all duration-200"
                  style={{ width: `${rebootProgress}%` }}
                />
              </div>
              <span className="mt-2 text-[10px] text-neutral-500">جاري إعادة التهيئة {rebootProgress}%</span>
            </div>
          ) : editingFile ? (
            /* Embedded gnu nano Text Editor Frame output */
            <div className="flex-1 p-3 flex flex-col bg-neutral-950" id="nano-editor-frame">
              <VirtualNano
                filename={editingFile.filename}
                initialContent={editingFile.content}
                onSave={handleSaveFileContent}
                onClose={() => setEditingFile(null)}
              />
            </div>
          ) : (
            /* Terminal shell logs stream view */
            <div className="flex-1 flex flex-col min-h-0">
              <div 
                id="terminal-history" 
                className="flex-1 overflow-y-auto p-4 font-mono text-xs leading-relaxed space-y-2 select-text scrollbar-thin scrollbar-thumb-neutral-800"
                dir="ltr"
              >
                {/* Simulated Logs Output */}
                {history.map((item) => {
                  let textClass = 'text-neutral-300';
                  if (item.type === 'input') textClass = 'text-white font-bold border-l-2 border-neutral-700 pl-1.5';
                  if (item.type === 'error') textClass = 'text-red-400 font-semibold';
                  if (item.type === 'success') textClass = 'text-neutral-400 font-bold';
                  if (item.type === 'warning') textClass = 'text-yellow-200/90 font-medium';
                  if (item.type === 'system') textClass = 'text-neutral-500 text-[11px]';
                  if (item.type === 'ascii') textClass = 'text-neutral-400 leading-tight block whitespace-pre';

                  return (
                    <div 
                      key={item.id} 
                      className={`break-words ${textClass} select-text whitespace-pre-wrap flex items-start gap-2.5 hover:bg-neutral-900/10 p-1.5 rounded-md transition-colors duration-100 group`}
                    >
                      {item.type !== 'ascii' && item.timestamp && (
                        <span 
                          className="text-[10px] text-neutral-600 font-mono shrink-0 select-none pt-0.5 tracking-tighter" 
                          title="تاريخ ووقت التنفيذ"
                        >
                          [{item.timestamp}]
                        </span>
                      )}
                      <div className="flex-1 min-w-0">
                        {item.text}
                      </div>
                    </div>
                  );
                })}
                <div ref={terminalEndRef} />
              </div>

              {/* Shell live prompt entry row */}
              <div className="bg-neutral-950 border-t border-neutral-900 p-2.5 flex items-center gap-2 select-none relative" dir="ltr">
                {/* Dynamic Parameter / Autocomplete Ghost Hint Tooltip */}
                {currentSuggestion && (
                  <div className="absolute bottom-full left-0 mb-1.5 ml-2 px-3 py-2 bg-[#09090b]/95 border border-neutral-850 rounded-lg shadow-xl flex flex-wrap items-center gap-2 z-25 transition-all duration-200 animate-in fade-in slide-in-from-bottom-1 max-w-[90%] backdrop-blur-md">
                    <span className="text-[9px] font-bold tracking-wider text-neutral-400 bg-neutral-900 border border-neutral-800 rounded px-1.5 py-0.5 select-none font-mono">
                      {currentSuggestion.isPartial ? 'TAB لإكمال' : 'معلمات الأمر'}
                    </span>
                    <span className="text-xs font-mono text-neutral-300">
                      <span className="text-emerald-400 font-bold">{currentSuggestion.command}</span>
                      <span className="text-neutral-400 select-all font-semibold">{currentSuggestion.hint}</span>
                    </span>
                  </div>
                )}

                {/* Static bash host directory index indicator */}
                <span className="text-neutral-400 font-bold shrink-0 text-xs font-mono select-none">
                  {isRoot ? 'root:/ #' : `android:${currentPath} $`}
                </span>

                <input
                  ref={inputRef}
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  onKeyDown={handleKeyDown}
                  className="flex-1 bg-transparent text-neutral-100 placeholder-neutral-600 font-mono text-sm border-none outline-none focus:outline-none focus:ring-0 p-0"
                  placeholder='اكتب الأمر هنا (مثال: help, ls, neofetch)...'
                  autoComplete="off"
                  autoCapitalize="off"
                  id="terminal-input"
                />

                {/* Blinking Unix line cursor emulation */}
                <span className="w-1.5 h-4 bg-neutral-400 animate-pulse shrink-0 self-center" />
              </div>

              {/* Mobile Helpful Termux Tool Pad */}
              <div className="bg-neutral-900 border-t border-neutral-850 p-2 grid grid-cols-4 sm:grid-cols-8 gap-1.5 text-center text-[10px] font-mono select-none">
                <button
                  type="button"
                  onClick={() => setInputVal(prev => prev + '/')}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-400 rounded transition font-bold"
                >
                  /
                </button>
                <button
                  type="button"
                  onClick={() => setInputVal(prev => prev + ' -')}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-400 rounded transition font-bold"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setInputVal(prev => prev + ' > ')}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-400 rounded transition font-bold"
                >
                  &gt;
                </button>
                <button
                  type="button"
                  onClick={handleAutocomplete}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-300 rounded transition font-bold flex items-center justify-center gap-1"
                  title="إكمال تلقائي"
                >
                  <Keyboard size={11} />
                  <span>TAB</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setInputVal('');
                    if (cmdHistory.length > 0) {
                      setInputVal(cmdHistory[cmdHistory.length - 1]);
                    }
                  }}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-300 rounded transition font-bold"
                >
                  أعلى ↑
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setHistory([]);
                  }}
                  className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-300 rounded transition font-bold"
                >
                  مسح
                </button>
                
                {/* Specific active long streams exit command button */}
                {isLogcatActive ? (
                  <button
                    type="button"
                    onClick={() => {
                      setIsLogcatActive(false);
                      setHistory(prev => [
                        ...prev,
                        {
                          id: 'logcat-term',
                          text: '[TERMINATED] تم إيقاف بث السجلات بنجاح.',
                          type: 'warning',
                          timestamp: getPreciseTimestamp()
                        }
                      ]);
                    }}
                    className="bg-red-950 hover:bg-red-900 col-span-2 py-1.5 text-red-100 rounded transition font-bold flex items-center justify-center gap-1.5"
                  >
                    <StopCircle size={11} />
                    <span>إيقاف Logcat</span>
                  </button>
                ) : (
                  <>
                    <button
                      type="button"
                      onClick={() => {
                        setInputVal('');
                        handleExecuteCommand('ls -la');
                      }}
                      className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-400 rounded transition"
                    >
                      ls -la
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setInputVal('');
                        handleExecuteCommand('neofetch');
                      }}
                      className="bg-neutral-950 hover:bg-neutral-800 py-1.5 text-neutral-400 rounded transition"
                    >
                      neofetch
                    </button>
                  </>
                )}
              </div>
            </div>
          )}
        </section>

        {/* RIGHT COLUMN: Interactive ADB/Terminal Commands Guide (Lg: 5/12) */}
        <section id="manual-section" className="lg:col-span-5 h-[580px] lg:h-full flex flex-col min-h-0">
          <ManualTabs 
            onInjectCommand={handleInjectCommand} 
            isPythonInstalled={isPythonInstalled}
            setIsPythonInstalled={setIsPythonInstalled}
            runningServers={runningServers}
            setRunningServers={setRunningServers}
            vfs={vfs}
          />
        </section>
      </main>

      {/* Footer Area - Human design credit with no telemetry block */}
      <footer id="footer-bar" className="bg-neutral-950 border-t border-neutral-900 py-2.5 px-4 flex flex-wrap items-center justify-between text-xs text-neutral-500 select-none">
        <div className="flex items-center gap-1.5">
          <Info size={13} className="text-neutral-600" />
          <span>ملاحظة: محاكي سطر أوامر تفاعلي معزز بنظام VFS داخلي محلي بالكامل للأمان والسرعة.</span>
        </div>
        <div className="font-sans">
          تصميم دقيق ومنظم لمطوري تطبيقات الهواتف الذكية والأندرويد بتدرجات الأسود والفحمي والرمادي الرزين.
        </div>
      </footer>
    </div>
  );
}
